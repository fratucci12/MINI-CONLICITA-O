# api.py
import os
import io
import re
import json
import time
import sqlite3
import zipfile
from datetime import datetime
from typing import Any, Dict, List, Tuple, Optional
import urllib.parse

import requests
from fastapi import FastAPI, HTTPException, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse, JSONResponse

# =========================
# Config & Flags (.env)
# =========================
DB_PATH = os.getenv("DB_PATH", "pncp_db.sqlite")
ANEXOS_DIR = os.getenv("ANEXOS_DIR", "anexos")

# Endpoints PNCP
PNCP_BASE  = os.getenv("PNCP_BASE",  "https://pncp.gov.br/api/consulta/v1")
PNCP_FILES = os.getenv("PNCP_FILES", "https://pncp.gov.br/pncp-api/v1")
RESOURCES  = ("compras", "dispensas", "inexigibilidades")

# Modos
PNCP_ONLY        = os.getenv("PNCP_ONLY", "0") == "1"      # usar só PNCP, sem DB
PNCP_FALLBACK    = os.getenv("PNCP_FALLBACK", "1") == "1"  # quando DB não tem, cai no PNCP
PNCP_SKIP_ANEXOS = os.getenv("PNCP_SKIP_ANEXOS", "0") == "1"  # não baixar/armazenar anexos

# Paginação (buscas/itens no PNCP)
PNCP_PAGE_SIZE = int(os.getenv("PNCP_PAGE_SIZE", "200"))
PNCP_MAX_PAGES = int(os.getenv("PNCP_MAX_PAGES", "2000"))
PNCP_SLEEP_S   = float(os.getenv("PNCP_SLEEP_S", "0.03"))

# Numero PNCP: CNPJ-?-SEQ/ANO (varia por instância; este cobre o formato mais comum)
_RX_NUM_CTRL = re.compile(r"^(\d{14})-\d-([0-9]{1,8})/(\d{4})$")
def _is_numero_pncp(s: str) -> bool:
    return bool(_RX_NUM_CTRL.match(str(s or "")))

def split_numero_pncp(num: str) -> Tuple[str, str, str]:
    m = _RX_NUM_CTRL.search(num or "")
    if not m:
        raise HTTPException(status_code=400, detail=f"numero_pncp inválido: {num}")
    cnpj, seq, ano = m.groups()
    return cnpj, ano, (seq.lstrip("0") or "0")

# =========================
# App & CORS
# =========================
app = FastAPI(title="Mini-ConLicitação API", version="2.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5500",
        "http://127.0.0.1:5500",
        "http://localhost:8000",
        "http://127.0.0.1:8000",
        "*",  # dev
    ],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

# =========================
# DB Schema
# =========================
DDL_PUBLICACOES = """
CREATE TABLE IF NOT EXISTS publicacoes (
  pub_id                 INTEGER PRIMARY KEY AUTOINCREMENT,
  numero_pncp            TEXT UNIQUE,
  orgao_nome             TEXT,
  orgao_cnpj             TEXT,
  uf                     TEXT,
  modalidade_nome        TEXT,
  modalidade_codigo      TEXT,
  sistema_publicador     TEXT,
  link_sistema_origem    TEXT,
  data_publicacao        TEXT,
  data_abertura          TEXT,
  data_encerramento      TEXT,
  objeto                 TEXT,
  json_bruto             TEXT,
  created_at             TEXT DEFAULT CURRENT_TIMESTAMP,
  updated_at             TEXT DEFAULT CURRENT_TIMESTAMP
);
"""

DDL_ANEXOS = """
CREATE TABLE IF NOT EXISTS anexos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  numero_pncp TEXT NOT NULL,
  tipo_documento_id INTEGER NULL,
  tipo_documento_nome TEXT NULL,
  titulo TEXT NOT NULL DEFAULT '',
  url_api TEXT NOT NULL DEFAULT '',
  saved_path TEXT NULL,
  content_type TEXT NULL,
  size_bytes INTEGER NULL,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
  UNIQUE (numero_pncp, titulo, url_api)
);
"""

DDL_ITENS = """
CREATE TABLE IF NOT EXISTS itens (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  numero_pncp TEXT NOT NULL,
  pub_id INTEGER NULL,
  cnpj TEXT NOT NULL,
  ano INTEGER NOT NULL,
  sequencial INTEGER NOT NULL,
  lote TEXT NOT NULL DEFAULT '',
  numero_item INTEGER,
  descricao TEXT,
  unidade TEXT,
  quantidade REAL,
  valor_unitario REAL,
  valor_total REAL,
  json_bruto TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
  UNIQUE (numero_pncp, lote, numero_item)
);
"""

def connect_db() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON;")
    conn.execute(DDL_PUBLICACOES)
    conn.execute(DDL_ANEXOS)
    conn.execute(DDL_ITENS)
    # migração leve (caso já exista sem colunas)
    try: conn.execute("ALTER TABLE publicacoes ADD COLUMN data_abertura TEXT")
    except sqlite3.OperationalError: pass
    try: conn.execute("ALTER TABLE publicacoes ADD COLUMN data_encerramento TEXT")
    except sqlite3.OperationalError: pass
    conn.commit()
    return conn

def query(sql: str, params: Tuple[Any, ...] = ()) -> List[Dict[str, Any]]:
    with connect_db() as conn:
        cur = conn.execute(sql, params)
        return [dict(r) for r in cur.fetchall()]

def query_one(sql: str, params: Tuple[Any, ...] = ()) -> Optional[Dict[str, Any]]:
    rows = query(sql, params)
    return rows[0] if rows else None

def _has_col(table: str, col: str) -> bool:
    with connect_db() as conn:
        cur = conn.execute(f"PRAGMA table_info({table})")
        return any(r["name"] == col for r in cur.fetchall())

def _dateexpr(tbl: str, candidates: tuple[str, ...]) -> str:
    exist = [c for c in candidates if _has_col(tbl, c)]
    if not exist:
        return "NULL"
    if len(exist) == 1:
        return exist[0]
    return "COALESCE(" + ", ".join(exist) + ")"

def _norm_dt(s: str | None, end=False) -> str | None:
    if not s: return None
    s = s.strip()
    try:
        if len(s) == 10:
            dt = datetime.fromisoformat(s + ("T23:59:59" if end else "T00:00:00"))
        elif len(s) == 16:
            dt = datetime.fromisoformat(s + ":00")
        else:
            dt = datetime.fromisoformat(s)
        return dt.isoformat(timespec="seconds")
    except Exception:
        return None

# =========================
# HTTP helpers (PNCP)
# =========================
def _http_get_json(url: str, params: dict | None = None, timeout=30):
    try:
        r = requests.get(url, params=params, timeout=timeout, headers={"Accept": "application/json"})
    except requests.RequestException as e:
        return None, 599, str(e)
    if r.status_code == 404:
        return None, 404, None
    if r.status_code != 200:
        return None, r.status_code, r.text
    try:
        return r.json(), 200, None
    except Exception:
        return None, 502, "non-JSON"

def _to_list(payload):
    if payload is None: return []
    if isinstance(payload, list): return payload
    if isinstance(payload, dict):
        for k in ("content","items","data","lista","resultado","itens","conteudo"):
            v = payload.get(k)
            if isinstance(v, list): return v
    return []

def _paged_fetch(url: str, params: dict | None = None):
    params = dict(params or {})
    page = int(params.pop("pagina", 1))
    size = int(params.pop("tamanhoPagina", PNCP_PAGE_SIZE))
    for _ in range(PNCP_MAX_PAGES):
        q = dict(params, pagina=page, tamanhoPagina=size)
        payload, sc, err = _http_get_json(url, params=q)
        if sc != 200 or not payload:
            break
        batch = _to_list(payload)
        if not batch:
            break
        for item in batch:
            yield item
        if len(batch) < size:
            break
        page += 1
        time.sleep(PNCP_SLEEP_S)

# =========================
# Normalização / UPSERT
# =========================
def _get(d: dict, *paths, default=None):
    for p in paths:
        cur = d
        ok = True
        for k in p.split("."):
            if isinstance(cur, dict) and k in cur:
                cur = cur[k]
            else:
                ok = False
                break
        if ok and cur not in (None, ""):
            return cur
    return default

def _norm_iso_sec(s: str|None) -> str|None:
    if not s: return None
    ss = s.strip().replace("Z","")
    try:
        if len(ss) == 10:  return datetime.fromisoformat(ss + "T00:00:00").isoformat(timespec="seconds")
        if len(ss) == 16:  return datetime.fromisoformat(ss + ":00").isoformat(timespec="seconds")
        return datetime.fromisoformat(ss).isoformat(timespec="seconds")
    except Exception:
        return s

def _upsert_publicacao_from_payload(numero_pncp: str, payload: dict) -> dict:
    orgao_nome  = _get(payload, "orgaoEntidade.razaoSocial", "unidadeOrgao.nomeUnidade", "orgaoNome")
    uf          = _get(payload, "unidadeOrgao.ufSigla", "ufSigla", "uf")
    modalidade  = _get(payload, "modalidadeNome", "modalidade.nome", "modalidade")
    modalidade_cod = str(_get(payload, "modalidade", "modalidadeCodigo", default="") or "")
    link_origem = _get(payload, "linkSistemaOrigem", "linkProcessoEletronico")
    data_pub    = _get(payload, "dataPublicacaoPNCP", "dataPublicacaoPncp", "dataPublicacao", "dataInclusao")
    objeto      = _get(payload, "objetoCompra", "descricao", "objeto")
    data_ab     = _get(payload, "dataAberturaProposta","dataInicioRecebimentoProposta","dataInicioPropostas","dataAbertura")
    data_en     = _get(payload, "dataEncerramentoProposta","dataFimRecebimentoProposta","dataEncerramento","data_enceramento")

    row = {
        "numero_pncp": numero_pncp,
        "orgao_nome": orgao_nome,
        "uf": uf,
        "modalidade_nome": modalidade,
        "modalidade_codigo": modalidade_cod,
        "sistema_publicador": _get(payload, "sistemaPublicador"),
        "link_sistema_origem": link_origem,
        "data_publicacao": _norm_iso_sec(data_pub),
        "data_abertura": _norm_iso_sec(data_ab),
        "data_encerramento": _norm_iso_sec(data_en),
        "objeto": objeto,
        "json_bruto": json.dumps(payload, ensure_ascii=False),
    }

    with connect_db() as con:
        con.execute("""
            INSERT INTO publicacoes
              (numero_pncp, orgao_nome, uf, modalidade_nome, modalidade_codigo,
               sistema_publicador, link_sistema_origem, data_publicacao,
               data_abertura, data_encerramento,
               objeto, json_bruto, updated_at)
            VALUES
              (:numero_pncp, :orgao_nome, :uf, :modalidade_nome, :modalidade_codigo,
               :sistema_publicador, :link_sistema_origem, :data_publicacao,
               :data_abertura, :data_encerramento,
               :objeto, :json_bruto, CURRENT_TIMESTAMP)
            ON CONFLICT(numero_pncp) DO UPDATE SET
               orgao_nome=excluded.orgao_nome,
               uf=excluded.uf,
               modalidade_nome=excluded.modalidade_nome,
               modalidade_codigo=excluded.modalidade_codigo,
               sistema_publicador=excluded.sistema_publicador,
               link_sistema_origem=excluded.link_sistema_origem,
               data_publicacao=excluded.data_publicacao,
               data_abertura=excluded.data_abertura,
               data_encerramento=excluded.data_encerramento,
               objeto=excluded.objeto,
               json_bruto=excluded.json_bruto,
               updated_at=CURRENT_TIMESTAMP
        """, row)
        saved = query_one("SELECT * FROM publicacoes WHERE numero_pncp=?", (numero_pncp,))
    return saved

def fetch_publicacao_meta_any(cnpj: str, ano: str, seq: str) -> Optional[dict]:
    for res in RESOURCES:
        url = f"{PNCP_FILES}/orgaos/{cnpj}/{res}/{ano}/{seq}"
        payload, sc, err = _http_get_json(url)
        if sc == 200 and isinstance(payload, dict) and payload:
            payload["_resource"] = res
            return payload
    return None

# =========================
# PNCP: Itens / Anexos
# =========================
def list_itens_any(cnpj: str, ano: str, seq: str) -> list[dict]:
    """
    Lista TODOS os itens, tentando rotas com e sem paginação e variações de path.
    """
    suffixes = ("itens", "itens.json", "item", "itens-lote", "itensLote", "itens/0")
    out: list[dict] = []

    for res in RESOURCES:
        base = f"{PNCP_FILES}/orgaos/{cnpj}/{res}/{ano}/{seq}"

        # 1) Sem paginação (muitas instâncias já devolvem tudo)
        url = f"{base}/itens"
        payload, sc, err = _http_get_json(url)
        if sc == 200 and payload:
            lst = _to_list(payload)
            if lst:
                for it in lst:
                    if isinstance(it, dict): it["_resource"] = res
                return lst

        # 2) Paginação explícita (se suportar)
        tmp: list[dict] = []
        try:
            for it in _paged_fetch(url, params={"pagina": 1, "tamanhoPagina": PNCP_PAGE_SIZE}):
                if isinstance(it, dict): it["_resource"] = res
                tmp.append(it)
        except Exception:
            tmp = []
        if tmp:
            return tmp

        # 3) Variações de path
        for suf in suffixes:
            url2 = f"{base}/{suf}"
            # 3a) sem paginação
            payload, sc, err = _http_get_json(url2)
            if sc == 200 and payload:
                lst = _to_list(payload)
                if lst:
                    for it in lst:
                        if isinstance(it, dict): it["_resource"] = res
                    return lst
            # 3b) com paginação
            tmp = []
            try:
                for it in _paged_fetch(url2, params={"pagina": 1, "tamanhoPagina": PNCP_PAGE_SIZE}):
                    if isinstance(it, dict): it["_resource"] = res
                    tmp.append(it)
            except Exception:
                tmp = []
            if tmp:
                return tmp

    return out

def list_arquivos_any(cnpj: str, ano: str, seq: str):
    for res in RESOURCES:
        url = f"{PNCP_FILES}/orgaos/{cnpj}/{res}/{ano}/{seq}/arquivos"
        payload, sc, err = _http_get_json(url)
        lst = _to_list(payload)
        if sc == 200 and lst:
            for a in lst:
                if isinstance(a, dict):
                    a["_resource"] = res
            return lst
    return []

def stream_arquivo(cnpj: str, ano: str, seq: str, resource: str, docseq: str):
    url = f"{PNCP_FILES}/orgaos/{cnpj}/{resource}/{ano}/{seq}/arquivos/{docseq}"
    r = requests.get(url, stream=True, timeout=60)
    if r.status_code != 200:
        raise HTTPException(status_code=r.status_code, detail=f"PNCP: {r.text[:200]}")
    ct = r.headers.get("Content-Type", "application/octet-stream")
    cd = r.headers.get("Content-Disposition", "")
    headers = {"Content-Disposition": cd} if cd else {}
    return StreamingResponse(r.iter_content(chunk_size=8192), media_type=ct, headers=headers)

# =========================
# Util: anexos locais
# =========================
def _resolve_saved_path(saved_path: str) -> Optional[str]:
    if not saved_path:
        return None
    p = saved_path.replace("\\", os.sep).replace("/", os.sep)
    rel = os.path.join(ANEXOS_DIR, p) if not os.path.isabs(p) else p
    if os.path.exists(rel):
        return rel
    if os.path.exists(p):
        return p
    return None

def _list_anexos_by_numero(numero_pncp: str) -> List[Dict[str, Any]]:
    return query(
        """SELECT id, numero_pncp, tipo_documento_nome, titulo, url_api, saved_path, content_type, size_bytes
           FROM anexos WHERE numero_pncp=? ORDER BY id""",
        (numero_pncp,),
    )

def _list_anexos_by_pubid(pub_id: int) -> List[Dict[str, Any]]:
    return query(
        """SELECT a.id, a.numero_pncp, a.tipo_documento_nome, a.titulo, a.url_api,
                  a.saved_path, a.content_type, a.size_bytes
           FROM anexos a
           JOIN publicacoes p ON p.numero_pncp = a.numero_pncp
           WHERE p.pub_id=? ORDER BY a.id""",
        (pub_id,),
    )

# =========================
# Health
# =========================
@app.get("/health")
def health():
    return {
        "ok": True,
        "message": "Mini-ConLicitação API",
        "endpoints": [
            "/health", "/buscar",
            "/detalhe/{numero_pncp}", "/detalhe_id/{pub_id}",
            "/anexos/{numero_pncp}", "/anexos_id/{pub_id}", "/anexos_id/{pub_id}/zip",
            "/itens/{numero_pncp}", "/itens_id/{pub_id}",
        ],
        "flags": {
            "PNCP_ONLY": PNCP_ONLY,
            "PNCP_FALLBACK": PNCP_FALLBACK,
            "PNCP_SKIP_ANEXOS": PNCP_SKIP_ANEXOS,
        }
    }

# =========================
# Buscar
# =========================
def _pncp_search_headers(q: str, limit: int = 50) -> list[dict]:
    out: list[dict] = []
    size = min(PNCP_PAGE_SIZE, limit) if limit else PNCP_PAGE_SIZE
    for res in RESOURCES:
        url = f"{PNCP_FILES}/{res}/busca"
        page = 1
        while True:
            payload, sc, err = _http_get_json(url, params={"pagina": page, "tamanhoPagina": size, "termo": q})
            if sc != 200 or not payload:
                break
            batch = _to_list(payload)
            if not batch:
                break
            for h in batch:
                if isinstance(h, dict):
                    h["_resource"] = res
                out.append(h)
            if limit and len(out) >= limit:
                return out[:limit]
            if len(batch) < size:
                break
            page += 1
            time.sleep(PNCP_SLEEP_S)
    return out if not limit else out[:limit]


@app.get("/buscar")
def buscar(q: str = "", in_itens: bool = True, uf: str = "", orgao: str = "", edital: str = "",
           modal: str = "", abertura_de: str = "", abertura_ate: str = "",
           encerramento_de: str = "", encerramento_ate: str = "", limit: int = 50):
    # Modo PNCP_ONLY: usa PNCP direto (apenas por termo q)
    if PNCP_ONLY:
        if not q:
            return []
        headers = _pncp_search_headers(q, limit=min(limit, 50))
        out: list[dict] = []
        for h in headers:
            numero = _get(h, "numeroControlePNCP", "numero_pncp")
            if not numero:
                continue
            try:
                cnpj, ano, seq = split_numero_pncp(numero)
            except HTTPException:
                continue
            payload = fetch_publicacao_meta_any(cnpj, ano, seq) or h
            out.append({
                "pub_id": numero,
                "numero_pncp": numero,
                "orgao_nome": _get(payload, "orgaoEntidade.razaoSocial", "unidadeOrgao.nomeUnidade", "orgaoNome"),
                "municipioNome": _get(payload, "unidadeOrgao.municipioNome", "municipioNome", "municipio"),
                "uf": _get(payload, "unidadeOrgao.ufSigla", "uf"),
                "modalidade_nome": _get(payload, "modalidadeNome", "modalidade.nome", "modalidade"),
                "modalidade_codigo": str(_get(payload, "modalidade", "modalidadeCodigo", default="") or ""),
                "edital": _get(payload, "numeroEdital", "numeroCompra", "edital"),
                "data_publicacao": _get(payload, "dataPublicacaoPNCP", "dataPublicacaoPncp", "dataPublicacao", "dataInclusao"),
                "dataAberturaProposta": _get(payload, "dataAberturaProposta", "dataInicioRecebimentoProposta", "dataInicioPropostas", "dataAbertura"),
                "dataEncerramentoProposta": _get(payload, "dataEncerramentoProposta", "dataFimRecebimentoProposta", "dataEncerramento", "data_enceramento"),
                "objeto": _get(payload, "objetoCompra", "descricao", "objeto"),
                "link_sistema_origem": _get(payload, "linkSistemaOrigem", "linkProcessoEletronico"),
                "json_bruto": json.dumps(payload, ensure_ascii=False),
            })
        # não há itens para cruzar nesse modo
        return out[:limit]

    # ===== Modo DB =====
    where, pr = [], []
    from_sql = "publicacoes p"
    join_sql = ""

    # Texto livre
    if q:
        t = f"%{q.strip()}%"
        # campos da publicacao
        campos_pub = ("objeto","orgao_nome","edital","numero_pncp","modalidade_nome","municipioNome")
        campos_pub = [c for c in campos_pub if _has_col("publicacoes", c)]
        conds = [f"UPPER(COALESCE(p.{c},'')) LIKE UPPER(?)" for c in campos_pub]
        pr.extend([t]*len(conds))

        # incluir itens na busca textual quando in_itens = true
        if in_itens and _has_col("itens","descricao"):
            join_sql = " LEFT JOIN itens i ON i.pub_id = p.pub_id"
            conds.append("UPPER(COALESCE(i.descricao,'')) LIKE UPPER(?)")
            pr.append(t)

        where.append("(" + " OR ".join(conds) + ")")

    # Filtros simples
    if uf:
        where.append("UPPER(COALESCE(p.uf,'')) = UPPER(?)"); pr.append(uf)
    if orgao:
        where.append("UPPER(COALESCE(p.orgao_nome,'')) LIKE UPPER(?)"); pr.append(f"%{orgao}%")
    if edital:
        where.append("UPPER(COALESCE(p.edital,'')) LIKE UPPER(?)"); pr.append(f"%{edital}%")
    if modal:
        if modal.isdigit():
            where.append("COALESCE(p.modalidade_codigo,'') = ?"); pr.append(modal)
        else:
            where.append("UPPER(COALESCE(p.modalidade_nome,'')) LIKE UPPER(?)"); pr.append(f"%{modal}%")

    # Filtros de datas
    ab_expr = _dateexpr("publicacoes", ("data_abertura","dataAberturaProposta","dataInicioRecebimentoProposta","dataInicioPropostas","dataAbertura"))
    en_expr = _dateexpr("publicacoes", ("data_encerramento","dataEncerramentoProposta","dataFimRecebimentoProposta","dataEncerramento","data_enceramento"))
    a_de  = _norm_dt(abertura_de, end=False); a_ate = _norm_dt(abertura_ate, end=True)
    e_de  = _norm_dt(encerramento_de, end=False); e_ate = _norm_dt(encerramento_ate, end=True)
    if ab_expr != "NULL":
        if a_de:  where.append(f"{ab_expr} >= ?"); pr.append(a_de)
        if a_ate: where.append(f"{ab_expr} <= ?"); pr.append(a_ate)
    if en_expr != "NULL":
        if e_de:  where.append(f"{en_expr} >= ?"); pr.append(e_de)
        if e_ate: where.append(f"{en_expr} <= ?"); pr.append(e_ate)

    sql = f"SELECT DISTINCT p.* FROM {from_sql}{join_sql}"
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += " ORDER BY datetime(COALESCE(p.updated_at, p.data_publicacao, p.created_at)) DESC"
    if limit:
        sql += f" LIMIT {int(limit)}"

    rows = query(sql, tuple(pr))

    # Semeadura via PNCP quando não retorna nada
    if not rows and PNCP_FALLBACK and q:
        headers = _pncp_search_headers(q, limit=min(limit or 50, 50))
        numeros = []
        for h in headers:
            numero = _get(h, "numeroControlePNCP", "numero_pncp")
            if not numero:
                continue
            try:
                cnpj, ano, seq = split_numero_pncp(numero)
            except HTTPException:
                continue
            payload = fetch_publicacao_meta_any(cnpj, ano, seq) or h
            _upsert_publicacao_from_payload(numero, payload)
            numeros.append(numero)

        if in_itens and numeros:
            for numero in numeros:
                try:
                    _upsert_itens_for_numero(numero)
                except Exception as e:
                    pass

        rows = query(sql, tuple(pr))

    return rows


# =========================
# Detalhe
# =========================
@app.get("/detalhe/{numero_pncp}")
def detalhe_numero(numero_pncp: str):
    row = query_one("SELECT * FROM publicacoes WHERE numero_pncp=?", (numero_pncp,))
    if row:
        return row
    if not PNCP_FALLBACK:
        raise HTTPException(404, "numero_pncp não encontrado")
    try:
        cnpj, ano, seq = split_numero_pncp(numero_pncp)
    except HTTPException:
        raise HTTPException(404, "numero_pncp não encontrado")
    payload = fetch_publicacao_meta_any(cnpj, ano, seq)
    if not payload:
        raise HTTPException(404, "numero_pncp não encontrado no PNCP")
    return _upsert_publicacao_from_payload(numero_pncp, payload)

@app.get("/detalhe_id/{pub_id}")
def detalhe_id(pub_id: int | str):
    if PNCP_ONLY:
        num = str(pub_id)
        if not _is_numero_pncp(num):
            raise HTTPException(404, "Neste modo, use numero_pncp como ID")
        cnpj, ano, seq = split_numero_pncp(num)
        payload = fetch_publicacao_meta_any(cnpj, ano, seq)
        if not payload:
            raise HTTPException(404, "não encontrado no PNCP")
        return {
            "pub_id": num,
            "numero_pncp": num,
            "json_bruto": json.dumps(payload, ensure_ascii=False),
            "objeto": _get(payload, "objetoCompra", "descricao", "objeto"),
            "orgao_nome": _get(payload, "orgaoEntidade.razaoSocial", "unidadeOrgao.nomeUnidade", "orgaoNome"),
            "municipioNome": _get(payload, "unidadeOrgao.municipioNome", "municipioNome", "municipio"),
            "uf": _get(payload, "unidadeOrgao.ufSigla", "uf"),
            "modalidade_nome": _get(payload, "modalidadeNome", "modalidade.nome", "modalidade"),
            "edital": _get(payload, "numeroEdital", "numeroCompra", "edital"),
            "data_publicacao": _get(payload, "dataPublicacaoPNCP", "dataPublicacaoPncp", "dataPublicacao", "dataInclusao"),
            "dataAberturaProposta": _get(payload, "dataAberturaProposta", "dataInicioRecebimentoProposta","dataInicioPropostas","dataAbertura"),
            "dataEncerramentoProposta": _get(payload, "dataEncerramentoProposta","dataFimRecebimentoProposta","dataEncerramento","data_enceramento"),
            "link_sistema_origem": _get(payload, "linkSistemaOrigem", "linkProcessoEletronico"),
        }
    row = query_one("SELECT * FROM publicacoes WHERE pub_id=?", (pub_id,))
    if not row:
        raise HTTPException(404, "pub_id não encontrado")
    return row

# =========================
# Anexos (sem baixar)
# =========================
@app.get("/anexos/{numero_pncp}")
def anexos_numero(numero_pncp: str):
    rows = _list_anexos_by_numero(numero_pncp)
    for r in rows:
        r["resolved_path"] = _resolve_saved_path(r.get("saved_path") or "")
    have_local = [r for r in rows if r.get("resolved_path")]
    if have_local or not PNCP_FALLBACK or PNCP_SKIP_ANEXOS:
        return rows
    # fallback: listar remoto sem baixar
    try:
        cnpj, ano, seq = split_numero_pncp(numero_pncp)
    except HTTPException:
        return rows
    remotos = list_arquivos_any(cnpj, ano, seq)
    out = []
    for a in remotos:
        docseq = a.get("sequencial_documento") or a.get("sequencialDocumento") or a.get("id")
        out.append({
            "id": docseq,
            "numero_pncp": numero_pncp,
            "tipo_documento_nome": a.get("tipo_documento_nome") or a.get("tipoDocumentoNome"),
            "titulo": a.get("titulo") or a.get("descricao"),
            "saved_path": None,
            "resolved_path": None,
            "remote": True,
            "resource": a.get("_resource"),
            "proxy_url": f"/anexos_numero/{numero_pncp}/remote/{a.get('_resource')}/{docseq}"
        })
    return out

@app.get("/anexos_id/{pub_id}")
def anexos_id(pub_id: int):
    rows = _list_anexos_by_pubid(pub_id)
    for r in rows:
        r["resolved_path"] = _resolve_saved_path(r.get("saved_path") or "")
    have_local = [r for r in rows if r.get("resolved_path")]
    if have_local or not PNCP_FALLBACK or PNCP_SKIP_ANEXOS:
        return rows

    row = query_one("SELECT numero_pncp FROM publicacoes WHERE pub_id=?", (pub_id,))
    if not row:
        raise HTTPException(status_code=404, detail="pub_id não encontrado")
    try:
        cnpj, ano, seq = split_numero_pncp(row["numero_pncp"])
    except HTTPException:
        return rows

    remotos = list_arquivos_any(cnpj, ano, seq)
    out = []
    for a in remotos:
        docseq = a.get("sequencial_documento") or a.get("sequencialDocumento") or a.get("id")
        out.append({
            "id": docseq,
            "numero_pncp": row["numero_pncp"],
            "tipo_documento_nome": a.get("tipo_documento_nome") or a.get("tipoDocumentoNome"),
            "titulo": a.get("titulo") or a.get("descricao"),
            "saved_path": None,
            "resolved_path": None,
            "remote": True,
            "resource": a.get("_resource"),
            "proxy_url": f"/anexos_id/{pub_id}/remote/{a.get('_resource')}/{docseq}"
        })
    return out

@app.get("/anexos_id/{pub_id}/remote/{resource}/{docseq}")
def anexos_id_remote(pub_id: int, resource: str, docseq: str):
    row = query_one("SELECT numero_pncp FROM publicacoes WHERE pub_id=?", (pub_id,))
    if not row:
        raise HTTPException(status_code=404, detail="pub_id não encontrado")
    cnpj, ano, seq = split_numero_pncp(row["numero_pncp"])
    return stream_arquivo(cnpj, ano, seq, resource, docseq)

@app.get("/anexos_numero/{numero_pncp}/remote/{resource}/{docseq}")
def anexos_numero_remote(numero_pncp: str, resource: str, docseq: str):
    cnpj, ano, seq = split_numero_pncp(numero_pncp)
    return stream_arquivo(cnpj, ano, seq, resource, docseq)

@app.get("/anexos_id/{pub_id}/zip")
def anexos_zip(pub_id: int):
    anexos = _list_anexos_by_pubid(pub_id)
    locais = []
    for a in anexos:
        p = _resolve_saved_path(a.get("saved_path") or "")
        if p: locais.append((p, a))
    if not locais:
        return Response(status_code=204)  # nada local para zipar (não baixa remoto)
    def gen_local():
        with io.BytesIO() as mem:
            with zipfile.ZipFile(mem, "w", zipfile.ZIP_DEFLATED) as z:
                for fullpath, meta in locais:
                    base = os.path.basename(fullpath)
                    tipo = (meta.get("tipo_documento_nome") or "DOC").strip()
                    titulo = (meta.get("titulo") or "").strip()
                    ext = os.path.splitext(base)[1] or ".bin"
                    seq = str(meta.get("id") or "0").zfill(3)
                    name_in_zip = f"{seq} - {tipo}" + (f" - {titulo}" if titulo else "") + ext
                    try:
                        z.write(fullpath, arcname=name_in_zip)
                    except Exception:
                        z.write(fullpath, arcname=base)
            mem.seek(0)
            yield from mem
    headers = {"Content-Disposition": f'attachment; filename="anexos_pub_{pub_id}.zip"'}
    return StreamingResponse(gen_local(), media_type="application/zip", headers=headers)

# =========================
# Itens
# =========================
def normalize_item_row(raw: dict) -> dict:
    def pick(*keys):
        for k in keys:
            v = raw.get(k)
            if v not in (None, ""): return v
        return None
    return {
        "numero_item":   pick("numero_item","numeroItem","sequencialItem","item","numero"),
        "descricao":     pick("descricao","objeto","descricaoItem","descricaoResumida","descricaoProduto"),
        "unidade":       pick("unidade","unidadeMedida","unidade_fornecimento","unidadeFornecimento"),
        "quantidade":    pick("quantidade","qtd","quantidadeTotal","qnt"),
        "valor_unitario":pick("valorUnitario","valor_unitario","precoUnitario","valorEstimadoUnitario"),
        "valor_total":   pick("valorTotal","valor_total","precoTotal","valorEstimadoTotal"),
        "lote":          pick("lote","numeroLote","sequencialLote"),
    }

@app.get("/itens_id/{pub_id}")
def itens_id(pub_id: int):
    # tenta DB
    rows = query("""
        SELECT numero_item, descricao, unidade, quantidade, valor_unitario, valor_total, lote
        FROM itens WHERE pub_id=? ORDER BY COALESCE(lote,''), numero_item
    """, (pub_id,))
    if rows:
        return rows
    # fallback PNCP
    if not PNCP_FALLBACK:
        return []
    row = query_one("SELECT numero_pncp FROM publicacoes WHERE pub_id=?", (pub_id,))
    if not row:
        raise HTTPException(status_code=404, detail="pub_id não encontrado")
    cnpj, ano, seq = split_numero_pncp(row["numero_pncp"])
    itens = list_itens_any(cnpj, ano, seq)
    return [normalize_item_row(it) for it in itens]

@app.get("/itens/{numero_pncp:path}")
def itens_numero(numero_pncp: str):
    cnpj, ano, seq = split_numero_pncp(numero_pncp)
    itens = list_itens_any(cnpj, ano, seq)
    return [normalize_item_row(it) for it in itens]
