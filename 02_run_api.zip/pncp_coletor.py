import os
import re
import io
import sys
import json
import time
import math
from dateutil import parser as dtparser
import argparse
import tempfile
import zipfile
import urllib.parse
import sqlite3
from datetime import datetime, date
from typing import Any, Dict, List, Optional, Tuple

import requests
from dateutil import parser as dtparser

# ==========================
# Config padrão (pode sobrescrever por ENV/CLI)
# ==========================
DB_PATH = os.getenv("DB_PATH", "pncp_db.sqlite")
ANEXOS_DIR = os.getenv("ANEXOS_DIR", "anexos")
TIMEOUT = int(os.getenv("HTTP_TIMEOUT", "40"))
RETRY = int(os.getenv("HTTP_RETRY", "3"))
SLEEP = float(os.getenv("HTTP_SLEEP", "0.25"))

# habilitar partes (1 = sim, 0 = não)
ENABLE_ANEXOS = os.getenv("DOWNLOAD_ANEXOS", "1") == "1"
ENABLE_ITENS = os.getenv("DOWNLOAD_ITENS", "1") == "1"

# Endpoints PNCP
PNCP_CONSULTA = "https://pncp.gov.br/api/consulta/v1"
PNCP_FILES    = "https://pncp.gov.br/pncp-api/v1"

# Recursos possíveis para itens/anexos
RESOURCES = ["compras", "dispensas", "inexigibilidades"]

# ==========================
# DB & DDL
# ==========================
DDL_PUBLICACOES = """
CREATE TABLE IF NOT EXISTS publicacoes (
  pub_id                 INTEGER PRIMARY KEY AUTOINCREMENT,
  numero_pncp            TEXT UNIQUE,
  orgao_nome             TEXT,
  orgao_cnpj             TEXT,
  uf                     TEXT,
  modalidade_nome        TEXT,
  modalidade_codigo      TEXT,
  sistema_publicador     TEXT,
  link_sistema_origem    TEXT,
  data_publicacao        TEXT,
  objeto                 TEXT,
  json_bruto             TEXT,
  created_at             TEXT DEFAULT CURRENT_TIMESTAMP,
  updated_at             TEXT DEFAULT CURRENT_TIMESTAMP
);
"""

DDL_ANEXOS = """
CREATE TABLE IF NOT EXISTS anexos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  numero_pncp TEXT NOT NULL,
  tipo_documento_id INTEGER NULL,
  tipo_documento_nome TEXT NULL,
  titulo TEXT NOT NULL DEFAULT '',
  url_api TEXT NOT NULL DEFAULT '',
  saved_path TEXT NULL,
  content_type TEXT NULL,
  size_bytes INTEGER NULL,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
  UNIQUE (numero_pncp, titulo, url_api)
);
"""


DDL_ITENS = """
CREATE TABLE IF NOT EXISTS itens (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  numero_pncp TEXT NOT NULL,
  pub_id INTEGER NULL,
  cnpj TEXT NOT NULL,
  ano INTEGER NOT NULL,
  sequencial INTEGER NOT NULL,
  lote TEXT NOT NULL DEFAULT '',
  numero_item INTEGER,
  descricao TEXT,
  unidade TEXT,
  quantidade REAL,
  valor_unitario REAL,
  valor_total REAL,
  json_bruto TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
  UNIQUE (numero_pncp, lote, numero_item)
);
"""


# tenta importar magic (opcional)
try:
    import magic  # python-magic-bin no Windows
except Exception:
    magic = None

_MIME_TO_EXT = {
    "application/pdf": ".pdf",
    "application/zip": ".zip",
    "application/json": ".json",
    "text/csv": ".csv",
    "text/plain": ".txt",
    "text/html": ".html",
    "application/rtf": ".rtf",
    "application/msword": ".doc",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document": ".docx",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": ".xlsx",
    "application/vnd.openxmlformats-officedocument.presentationml.presentation": ".pptx",
    "application/vnd.ms-excel": ".xls",
    "image/jpeg": ".jpg",
    "image/png": ".png",
    "image/gif": ".gif",
}

def _decode_content_disposition_filename(cd: str) -> Optional[str]:
    if not cd:
        return None
    # filename* tem prioridade (RFC 5987)
    # Ex: filename*=UTF-8''EDITAL%20PE%2060-2025.pdf
    parts = [p.strip() for p in cd.split(";")]
    kv = {}
    for p in parts:
        if "=" in p:
            k, v = p.split("=", 1)
            kv[k.lower()] = v.strip().strip('"')
    if "filename*" in kv:
        v = kv["filename*"]
        # formato: utf-8''nome%20arquivo.pdf
        try:
            enc, rest = v.split("''", 1)
            return urllib.parse.unquote(rest)
        except Exception:
            pass
    if "filename" in kv:
        return kv["filename"]
    return None

def _ext_from_content_type(ct: Optional[str]) -> Optional[str]:
    if not ct:
        return None
    ct = ct.split(";")[0].strip().lower()
    return _MIME_TO_EXT.get(ct)

def _ext_from_url(url: str) -> Optional[str]:
    try:
        path = urllib.parse.urlparse(url).path
        ext = os.path.splitext(path)[1].lower()
        if ext and len(ext) <= 6 and all(c.isalnum() or c in "._" for c in ext):
            return ext
    except Exception:
        pass
    return None

def _sniff_ext_from_bytes(head: bytes) -> Optional[str]:
    # PDF
    if head.startswith(b"%PDF-"):
        return ".pdf"
    # ZIP/Office (PK\x03\x04)
    if head[:4] == b"PK\x03\x04":
        # Tentar identificar docx/xlsx/pptx lendo membros do ZIP (em memória)
        try:
            with zipfile.ZipFile(io.BytesIO(head)) as z:
                names = set(z.namelist())
                if any(n.startswith("word/") for n in names):
                    return ".docx"
                if any(n.startswith("xl/") for n in names):
                    return ".xlsx"
                if any(n.startswith("ppt/") for n in names):
                    return ".pptx"
        except Exception:
            pass
        return ".zip"
    # imagens comuns
    if head.startswith(b"\xFF\xD8\xFF"):
        return ".jpg"
    if head.startswith(b"\x89PNG\r\n\x1a\n"):
        return ".png"
    if head[:6] in (b"GIF87a", b"GIF89a"):
        return ".gif"
    return None

def _ext_from_magic(tmp_path: str, head: bytes) -> Optional[str]:
    # tenta magic primeiro
    if magic:
        try:
            mime = magic.from_buffer(head, mime=True)
            if mime:
                e = _MIME_TO_EXT.get(mime.lower())
                if e:
                    return e
        except Exception:
            pass
    # fallback manual
    return _sniff_ext_from_bytes(head)

def _sanitize_filename(name: str, maxlen: int = 140) -> str:
    name = name.replace("/", " ").replace("\\", " ").replace(":", " ").replace("|"," ").replace("*"," ")
    name = name.replace("?", " ").replace('"', " ").replace("<"," ").replace(">"," ")
    name = " ".join(name.split())
    return name[:maxlen].strip()

def connect_db() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL;")
    conn.execute("PRAGMA foreign_keys=ON;")
    conn.execute(DDL_PUBLICACOES)
    conn.execute(DDL_ANEXOS)
    conn.execute(DDL_ITENS)
    conn.commit()
    return conn

# ==========================
# Utils
# ==========================
PAT_NUM_PNCP = re.compile(r"(\d{14})-\d-(\d{1,8})/(\d{4})")

def split_numero_pncp(numero: str) -> Tuple[str, str, str]:
    m = PAT_NUM_PNCP.search(numero or "")
    if not m:
        raise ValueError(f"numero_pncp inválido: {numero}")
    cnpj, seq, ano = m.groups()
    seq = seq.lstrip("0") or "0"
    return cnpj, ano, seq

def ensure_dir(p: str):
    os.makedirs(p, exist_ok=True)

def http_get(url: str, stream: bool=False, expected: List[int]=[200]) -> requests.Response:
    last_err = None
    for i in range(RETRY):
        try:
            r = requests.get(url, timeout=TIMEOUT, headers={"Accept": "*/*"}, stream=stream)
            if r.status_code in expected:
                return r
            last_err = Exception(f"{r.status_code} {r.text[:200]}")
        except requests.RequestException as e:
            last_err = e
        time.sleep(SLEEP * (i + 1))
    raise last_err

def to_list(payload: Any) -> List[dict]:
    if payload is None: return []
    if isinstance(payload, list): return payload
    if isinstance(payload, dict):
        for k in ("data", "items", "conteudo", "resultado", "itens"):
            v = payload.get(k)
            if isinstance(v, list): return v
    return []

def with_pages(url: str) -> List[str]:
    if "?" in url:
        base, qs = url.split("?", 1)
        return [url, f"{base}?pagina=1&tamanhoPagina=500&{qs}"]
    return [url, f"{url}?pagina=1&tamanhoPagina=500"]

def safe_float(x):
    if x is None: return None
    try:
        return float(str(x).replace(",", "."))
    except Exception:
        return None

def guess_ext_from_content_type(ct: Optional[str]) -> str:
    return _ext_from_content_type(ct) or ".bin"

def download_anexo(cnpj: str, ano: str, seq: str, doc_seq: str, titulo: str, tipo_nome: str) -> Tuple[str, str, int]:
    """
    Baixa um arquivo para ANEXOS_DIR/<cnpj>/<ano>/<seq>/
    Decide a extensão pela ordem:
      1) Content-Disposition filename / filename*
      2) URL
      3) Content-Type
      4) magic/assinatura do conteúdo
    Retorna (saved_path_relativo, content_type, size_bytes)
    """
    last_err = None
    for res in RESOURCES:
        url = f"{PNCP_FILES}/orgaos/{cnpj}/{res}/{ano}/{seq}/arquivos/{doc_seq}"
        try:
            r = http_get(url, stream=True)
        except Exception as e:
            last_err = e
            continue

        ct = r.headers.get("Content-Type", "")
        cd = r.headers.get("Content-Disposition", "") or r.headers.get("content-disposition", "")

        # 1) nome do cabeçalho (se houver)
        cd_name = _decode_content_disposition_filename(cd)
        cd_ext = os.path.splitext(cd_name)[1].lower() if cd_name else None

        # 2) ext da URL
        url_ext = _ext_from_url(url)

        # 3) ext do content-type
        ct_ext = _ext_from_content_type(ct)

        # Download para temp file (pra inspecionar o conteúdo)
        ensure_dir(ANEXOS_DIR)
        with tempfile.NamedTemporaryFile(delete=False) as tf:
            tmp_path = tf.name
            size = 0
            head = b""
            for chunk in r.iter_content(chunk_size=8192):
                if not chunk:
                    continue
                if size < 65536:
                    # guarda até 64KB pra sniff
                    need = 65536 - size
                    head += chunk[:need]
                tf.write(chunk)
                size += len(chunk)

        # 4) ext por magic/assinatura
        magic_ext = _ext_from_magic(tmp_path, head)

        # escolha final de extensão
        ext = cd_ext or url_ext or ct_ext or magic_ext or ".bin"

        # Montar nome final
        base_dir = os.path.join(ANEXOS_DIR, cnpj, ano, seq)
        ensure_dir(base_dir)

        safe_titulo = _sanitize_filename(titulo or "")
        safe_tipo = _sanitize_filename(tipo_nome or "DOC", 60)

        # Se o filename do header existir, aproveite-o (mas preserve prefixo sequencial)
        if cd_name:
            final_name = f"{str(doc_seq).zfill(3)} - {safe_tipo} - {_sanitize_filename(os.path.splitext(cd_name)[0])}{ext}"
        else:
            final_name = f"{str(doc_seq).zfill(3)} - {safe_tipo}"
            if safe_titulo:
                final_name += f" - {safe_titulo}"
            final_name += ext

        full = os.path.join(base_dir, final_name)

        # Se já existir, cria sufixo (1), (2), ...
        base_no_ext, _ = os.path.splitext(full)
        counter = 1
        while os.path.exists(full):
            full = f"{base_no_ext} ({counter}){ext}"
            counter += 1

        # mover tmp para destino
        try:
            os.replace(tmp_path, full)
        except Exception:
            # se algo der errado no rename, tenta copiar
            with open(tmp_path, "rb") as fsrc, open(full, "wb") as fdst:
                fdst.write(fsrc.read())
            try:
                os.remove(tmp_path)
            except Exception:
                pass

        rel = os.path.relpath(full, ".").replace("\\", "/")
        return (rel, ct, size)

    raise RuntimeError(f"Falha ao baixar anexo {doc_seq} ({titulo}) – {last_err}")

# ==========================
# Upserts
# ==========================
def upsert_publicacao(conn: sqlite3.Connection, data: Dict[str, Any]) -> int:
    conn.execute(
        """
        INSERT INTO publicacoes
          (numero_pncp, orgao_nome, orgao_cnpj, uf, modalidade_nome, modalidade_codigo,
           sistema_publicador, link_sistema_origem, data_publicacao, objeto, json_bruto,
           created_at, updated_at)
        VALUES
          (:numero_pncp, :orgao_nome, :orgao_cnpj, :uf, :modalidade_nome, :modalidade_codigo,
           :sistema_publicador, :link_sistema_origem, :data_publicacao, :objeto, :json_bruto,
           CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
        ON CONFLICT(numero_pncp) DO UPDATE SET
          orgao_nome=excluded.orgao_nome,
          orgao_cnpj=excluded.orgao_cnpj,
          uf=excluded.uf,
          modalidade_nome=excluded.modalidade_nome,
          modalidade_codigo=excluded.modalidade_codigo,
          sistema_publicador=excluded.sistema_publicador,
          link_sistema_origem=excluded.link_sistema_origem,
          data_publicacao=excluded.data_publicacao,
          objeto=excluded.objeto,
          json_bruto=excluded.json_bruto,
          updated_at=CURRENT_TIMESTAMP;
        """,
        data,
    )
    conn.commit()
    row = conn.execute("SELECT pub_id FROM publicacoes WHERE numero_pncp=?", (data["numero_pncp"],)).fetchone()
    return int(row[0])

def upsert_anexo(conn: sqlite3.Connection, data: Dict[str, Any]):
    conn.execute(
        """
    INSERT INTO anexos
        (numero_pncp, tipo_documento_id, tipo_documento_nome, titulo, url_api,
        saved_path, content_type, size_bytes, created_at, updated_at)
        VALUES
        (:numero_pncp, :tipo_documento_id, :tipo_documento_nome, :titulo, :url_api,
        :saved_path, :content_type, :size_bytes, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
        ON CONFLICT(numero_pncp, titulo, url_api) DO UPDATE SET
        tipo_documento_id=excluded.tipo_documento_id,
        tipo_documento_nome=excluded.tipo_documento_nome,
        saved_path=excluded.saved_path,
        content_type=excluded.content_type,
        size_bytes=excluded.size_bytes,
        updated_at=CURRENT_TIMESTAMP;
        """,
        data,
    )

def upsert_item(conn: sqlite3.Connection, data: Dict[str, Any]):
    conn.execute(
        """
        INSERT INTO itens
        (numero_pncp, pub_id, cnpj, ano, sequencial, lote, numero_item,
        descricao, unidade, quantidade, valor_unitario, valor_total, json_bruto,
        created_at, updated_at)
        VALUES
        (:numero_pncp, :pub_id, :cnpj, :ano, :sequencial, :lote, :numero_item,
        :descricao, :unidade, :quantidade, :valor_unitario, :valor_total, :json_bruto,
        CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
        ON CONFLICT(numero_pncp, lote, numero_item) DO UPDATE SET
        descricao=excluded.descricao,
        unidade=excluded.unidade,
        quantidade=excluded.quantidade,
        valor_unitario=excluded.valor_unitario,
        valor_total=excluded.valor_total,
        json_bruto=excluded.json_bruto,
        updated_at=CURRENT_TIMESTAMP;
        """,
        data,
    )

# ==========================
# Fetchers PNCP
# ==========================
def fetch_publicacoes(datainicial: str, datafinal: str,
                      modalidade: Optional[str], uf: Optional[str],
                      page: int, size: int) -> Dict[str, Any]:
    """
    Chama /consulta/v1/contratacoes/publicacao passando os parâmetros corretos.
    """
    url = f"{PNCP_CONSULTA}/contratacoes/publicacao"
    params = {
        "dataInicial": datainicial,     # YYYYMMDD
        "dataFinal": datafinal,         # YYYYMMDD
        "pagina": page,
        "tamanhoPagina": size,
    }
    if modalidade:
        params["codigoModalidadeContratacao"] = modalidade
    if uf:
        params["uf"] = uf

    # faça apenas UMA chamada (com params)
    r = requests.get(url, params=params, timeout=TIMEOUT, headers={"Accept": "application/json"})
    if r.status_code != 200:
        # log amigável pra depurar
        raise RuntimeError(
            f"{r.status_code} ao consultar publicacoes: url={url} params={params} body={r.text[:300]}"
        )
    return r.json()


def normalize_pub(row: Dict[str, Any]) -> Dict[str, Any]:
    # tentativas de nomes (o PNCP muda conforme recurso)
    numero = (row.get("numeroControlePNCP") or row.get("numeroPNCP") or row.get("numero_pncp"))
    orgao_nome = row.get("orgaoEntidade", {}).get("razaoSocial") or row.get("orgao_nome") or row.get("orgao")
    orgao_cnpj = row.get("orgaoEntidade", {}).get("cnpj") or row.get("orgao_cnpj")
    uf = (row.get("orgaoEntidade", {}).get("ufNomeSigla") or row.get("uf") or row.get("ufSigla") or "").strip() or None
    modalidade_nome = row.get("modalidadeNome") or row.get("modalidade_nome")
    modalidade_codigo = str(row.get("modalidadeId") or row.get("codigoModalidadeContratacao") or row.get("modalidade_codigo") or "")
    sistema_publicador = row.get("sistema") or row.get("sistema_publicador") or row.get("sistemaPublicador")
    link_sistema_origem = row.get("linkSistemaOrigem") or row.get("link_sistema_origem") or row.get("link_sistema")
    data_publicacao = (row.get("dataPublicacaoPNCP") or row.get("dataPublicacao") or row.get("dataInclusao") or row.get("created_at"))
    objeto = row.get("objeto") or row.get("descricao") or row.get("descricaoResumida")

    if not numero:
        raise ValueError("Publicação sem numero_pncp")

    return {
        "numero_pncp": numero,
        "orgao_nome": orgao_nome,
        "orgao_cnpj": orgao_cnpj,
        "uf": uf,
        "modalidade_nome": modalidade_nome,
        "modalidade_codigo": modalidade_codigo,
        "sistema_publicador": sistema_publicador,
        "link_sistema_origem": link_sistema_origem,
        "data_publicacao": data_publicacao,
        "objeto": objeto,
        "json_bruto": json.dumps(row, ensure_ascii=False),
    }

def list_arquivos_any(cnpj: str, ano: str, seq: str) -> List[Dict[str, Any]]:
    """
    Tenta listar anexos em compras/dispensas/inexigibilidades
    """
    for res in RESOURCES:
        url = f"{PNCP_FILES}/orgaos/{cnpj}/{res}/{ano}/{seq}/arquivos"
        try:
            r = http_get(url)
            payload = r.json()
        except Exception:
            continue
        lst = to_list(payload)
        if lst:
            for a in lst:
                a["_resource"] = res
            return lst
    return []


def try_itens(resource: str, cnpj: str, ano: str, seq: str) -> List[Dict[str, Any]]:
    base = f"{PNCP_FILES}/orgaos/{cnpj}/{resource}/{ano}/{seq}"
    for u in with_pages(f"{base}/itens"):
        try:
            r = http_get(u)
            lst = to_list(r.json())
            if lst: return lst
        except Exception:
            pass
    # por lote
    try:
        r = http_get(f"{base}/lotes")
        lotes = to_list(r.json())
    except Exception:
        lotes = []
    agg: List[Dict[str, Any]] = []
    if lotes:
        for lote in lotes:
            num = lote.get("numeroLote") or lote.get("numero") or lote.get("sequencialLote") or lote.get("lote") or lote.get("id")
            if num is None: 
                continue
            for val in {str(num), str(num).lstrip("0")}:
                for u in with_pages(f"{base}/lotes/{val}/itens"):
                    try:
                        rx = http_get(u)
                        lst = to_list(rx.json())
                        if lst:
                            for it in lst: it["_lote"] = num
                            agg.extend(lst)
                            break
                    except Exception:
                        pass
                if agg and agg[-1].get("_lote") == num:
                    break
    return agg

def fetch_itens_any(cnpj: str, ano: str, seq: str) -> List[Dict[str, Any]]:
    for res in RESOURCES:
        items = try_itens(res, cnpj, ano, seq)
        if items:
            return items
    return []

# ==========================
# MAIN
# ==========================
def run(datainicial: str, datafinal: str, modalidade: Optional[str], uf: Optional[str],
        tamanho_pagina: int, max_paginas: int):
    """
    datainicial/datafinal no formato YYYYMMDD (requerido pelo PNCP)
    """
    conn = connect_db()
    page = 1
    total_registros = 0

    while True:
        print(f"[PUB] Página {page}…", flush=True)
        try:
            payload = fetch_publicacoes(datainicial, datafinal, modalidade, uf, page, tamanho_pagina)
        except Exception as e:
            print(f"[ERRO] publicacoes page={page}: {e}")
            break

        lista = to_list(payload)
        if not lista:
            print("[PUB] Página vazia. Fim.")
            break

        for pub in lista:
            try:
                n = normalize_pub(pub)
            except Exception as e:
                print(f"[SKIP] pub sem numero_pncp: {e}")
                continue

            pub_id = upsert_publicacao(conn, n)
            total_registros += 1
            print(f"  • {n['numero_pncp']}  (pub_id={pub_id})")

            # ------- ANEXOS -------
            if ENABLE_ANEXOS:
                try:
                    cnpj, ano, seq = split_numero_pncp(n["numero_pncp"])
                    arquivos = list_arquivos_any(cnpj, ano, seq)
                    if arquivos:
                        print(f"    - anexos: {len(arquivos)}")
                    for doc in arquivos:
                        doc_seq = doc.get("sequencial_documento") or doc.get("sequencialDocumento") or doc.get("id") or 0
                        tipo_id = doc.get("tipo_documento_id") or doc.get("tipoDocumentoId") or None
                        tipo_nome = doc.get("tipo_documento_nome") or doc.get("tipoDocumentoNome") or doc.get("tipo") or ""
                        titulo = doc.get("titulo") or doc.get("descricao") or ""
                        url_api = (doc.get("url_api") or doc.get("url") or
                                   f"{PNCP_FILES}/orgaos/{cnpj}/{doc.get('_resource','compras')}/{ano}/{seq}/arquivos/{doc_seq}")
                        saved_path = None
                        content_type = None
                        size_bytes = None
                        try:
                            saved_path, content_type, size_bytes = download_anexo(cnpj, ano, seq, str(doc_seq), titulo, tipo_nome)
                        except Exception as e:
                            print(f"      [!] Falha download anexo {doc_seq}: {e}")

                        upsert_anexo(conn, {
                            "numero_pncp": n["numero_pncp"],
                            "tipo_documento_id": tipo_id,
                            "tipo_documento_nome": tipo_nome,
                            "titulo": (titulo or ""),          # <- normalize
                            "url_api": (url_api or ""),        # <- normalize
                            "saved_path": saved_path,
                            "content_type": content_type,
                            "size_bytes": size_bytes,
                        })

                    conn.commit()
                except Exception as e:
                    print(f"    [!] Erro anexos: {e}")

            # ------- ITENS -------
            if ENABLE_ITENS:
                try:
                    cnpj, ano, seq = split_numero_pncp(n["numero_pncp"])
                    itens = fetch_itens_any(cnpj, ano, seq)
                    if itens:
                        print(f"    - itens: {len(itens)}")
                    else:
                        print(f"    - itens: []")
                    for it in itens:
                        num = (it.get("numeroItem") or it.get("numero") or it.get("sequencialItem") or it.get("item"))
                        try:
                            numero_item = int(str(num)) if num is not None else None
                        except Exception:
                            numero_item = None

                        desc = it.get("descricao") or it.get("descricaoItem") or it.get("objeto") or ""
                        und  = it.get("unidadeFornecimento") or it.get("unidade") or it.get("unidadeMedida") or ""
                        qtd  = it.get("quantidadeTotal") or it.get("quantidade") or it.get("qtde") or it.get("qtd")
                        vu   = it.get("valorUnitarioEstimado") or it.get("valorUnitario")
                        vt   = it.get("valorTotalEstimado") or it.get("valorTotal") or (
                               safe_float(qtd) * safe_float(vu) if (safe_float(qtd) is not None and safe_float(vu) is not None) else None)

                        upsert_item(conn, {
                            "numero_pncp": n["numero_pncp"],
                            "pub_id": pub_id,
                            "cnpj": cnpj,
                            "ano": int(ano),
                            "sequencial": int(seq),
                            "lote": str(it.get("_lote") or it.get("lote") or it.get("numeroLote") or "")[:64],  # <- normalize para ''
                            "numero_item": numero_item,
                            "descricao": desc,
                            "unidade": und,
                            "quantidade": safe_float(qtd),
                            "valor_unitario": safe_float(vu),
                            "valor_total": safe_float(vt),
                            "json_bruto": json.dumps(it, ensure_ascii=False),
                        })

                    conn.commit()
                except Exception as e:
                    print(f"    [!] Erro itens: {e}")

        page += 1
        if max_paginas and page > max_paginas:
            print("[INFO] atingiu max_paginas.")
            break

    print(f"[OK] Publicações processadas: {total_registros}")

# ==========================
# CLI
# ==========================
def ymd(dt: str) -> str:
    # aceita 2025-08-14 ou 20250814
    dt = dt.strip()
    if re.fullmatch(r"\d{8}", dt):
        return dt
    d = dtparser.parse(dt).date()
    return d.strftime("%Y%m%d")

def main():
    ap = argparse.ArgumentParser("PNCP Coletor")
    ap.add_argument("--datai", default=(date.today().strftime("%Y%m%d")), help="data inicial (YYYYMMDD)")
    ap.add_argument("--dataf", default=(date.today().strftime("%Y%m%d")), help="data final (YYYYMMDD)")
    ap.add_argument("--modal", default=os.getenv("MODALIDADE", ""), help="codigoModalidadeContratacao (ex.: 6 = Pregão Eletrônico)")
    ap.add_argument("--uf", default=os.getenv("UF", ""), help="UF (ex.: RO)")
    ap.add_argument("--size", type=int, default=int(os.getenv("PAGE_SIZE", "50")), help="tamanhoPagina (default 50)")
    ap.add_argument("--pages", type=int, default=int(os.getenv("MAX_PAGES", "0")), help="limite de páginas (0 = sem limite)")
    ap.add_argument("--no-anexos", action="store_true", help="não baixar anexos")
    ap.add_argument("--no-itens", action="store_true", help="não coletar itens")
    args = ap.parse_args()

    global ENABLE_ANEXOS, ENABLE_ITENS
    ENABLE_ANEXOS = ENABLE_ANEXOS and (not args.no_anexos)
    ENABLE_ITENS  = ENABLE_ITENS  and (not args.no_itens)

    di = ymd(args.datai)
    df = ymd(args.dataf)

    # Evita 400 por datas futuras
    today_ymd = date.today().strftime("%Y%m%d")
    if di > today_ymd: di = today_ymd
    if df > today_ymd: df = today_ymd
    if di > df: di, df = df, di

    print(f"[START] data: {di}..{df}  modal={args.modal or '-'}  uf={args.uf or '-'}  anexos={ENABLE_ANEXOS} itens={ENABLE_ITENS}")
    run(di, df, args.modal or None, args.uf or None, args.size, args.pages)

if __name__ == "__main__":
    main()
