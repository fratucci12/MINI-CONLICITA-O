# fix_anexos_paths.py
import os, re, sqlite3, argparse, mimetypes
from glob import glob

DEFAULT_DB = os.getenv("DB_PATH", "pncp_db.sqlite")
DEFAULT_ANEXOS = os.getenv("ANEXOS_DIR", "anexos")

PAT_NUM = re.compile(r"(\d{14})-\d-(\d{1,8})/(\d{4})")
PAT_DOCSEQ_URL = re.compile(r"/arquivos/(\d+)$")

MIME_FIX = {
    ".pdf": "application/pdf",
    ".zip": "application/zip",
    ".doc": "application/msword",
    ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    ".xls": "application/vnd.ms-excel",
    ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    ".pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    ".rtf": "application/rtf",
    ".txt": "text/plain",
    ".csv": "text/csv",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".png": "image/png",
    ".gif": "image/gif",
}

def guess_mime(path):
    ext = os.path.splitext(path)[1].lower()
    return MIME_FIX.get(ext) or (mimetypes.guess_type(path)[0] or "application/octet-stream")

def norm_rel(root, path):
    p = os.path.abspath(path)
    root = os.path.abspath(root)
    try:
        rel = os.path.relpath(p, root)
    except Exception:
        rel = p
    return rel.replace("\\", "/")

def split_numero_pncp(numero):
    m = PAT_NUM.search(numero or "")
    if not m: return None, None, None
    cnpj, seq, ano = m.groups()
    return cnpj, (seq.lstrip("0") or "0"), ano

def folder_for(anexos_dir, numero):
    cnpj, seq, ano = split_numero_pncp(numero)
    if not cnpj: return None
    return os.path.join(anexos_dir, cnpj, ano, seq)

def find_candidate_by_docseq(folder, docseq):
    pad = str(docseq).zfill(3)
    files = sorted(glob(os.path.join(folder, f"{pad} - *")))
    return files[0] if files else None

def sanitize(s):
    return re.sub(r"[\\/:*?\"<>|]+", " ", (s or "")).strip().lower()

def find_candidate_by_titulo(folder, titulo):
    if not titulo: return None
    base = sanitize(titulo)
    for path in glob(os.path.join(folder, "*")):
        if base and base in sanitize(os.path.basename(path)):
            return path
    return None

def resolve_saved_path(anexos_dir, saved_path):
    if not saved_path:
        return None
    p = saved_path.replace("\\", "/")
    # 1) já relativo a raiz do projeto?
    if os.path.exists(p):
        return os.path.abspath(p)
    # 2) absoluto?
    if os.path.isabs(p) and os.path.exists(p):
        return p
    # 3) relativo à pasta de anexos
    alt = os.path.join(anexos_dir, p)
    if os.path.exists(alt):
        return os.path.abspath(alt)
    return None

def main():
    ap = argparse.ArgumentParser("Reconciliador de anexos (atualiza saved_path no SQLite)")
    ap.add_argument("--db", default=DEFAULT_DB, help="caminho do SQLite (default: pncp_db.sqlite)")
    ap.add_argument("--anexos", default=DEFAULT_ANEXOS, help="pasta de anexos (default: anexos)")
    ap.add_argument("--apply", action="store_true", help="aplica as correções no banco")
    args = ap.parse_args()

    db_path = os.path.abspath(args.db)
    anexos_dir = os.path.abspath(args.anexos)
    proj_root = os.path.abspath(".")

    if not os.path.exists(db_path):
        print(f"[ERRO] DB não encontrado: {db_path}")
        return
    if not os.path.isdir(anexos_dir):
        print(f"[ERRO] Pasta de anexos não encontrada: {anexos_dir}")
        return

    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row

    ok = fixed = missing = 0

    rows = conn.execute("""
        SELECT id, numero_pncp, url_api, titulo, tipo_documento_nome, saved_path, content_type, size_bytes
        FROM anexos ORDER BY id
    """).fetchall()

    for r in rows:
        id = r["id"]
        numero = r["numero_pncp"]
        url_api = r["url_api"] or ""
        titulo = r["titulo"] or ""
        saved = r["saved_path"] or ""

        # 1) caminho atual ainda existe?
        exist = resolve_saved_path(anexos_dir, saved)
        if exist:
            rel = norm_rel(proj_root, exist)
            st = os.stat(exist)
            mime = guess_mime(exist)
            if rel != saved or r["size_bytes"] != st.st_size or (r["content_type"] or "") != mime:
                print(f"[UPDATE] id={id} → saved_path='{rel}' ({st.st_size} bytes, {mime})")
                if args.apply:
                    conn.execute("""
                        UPDATE anexos SET saved_path=?, size_bytes=?, content_type=?, updated_at=CURRENT_TIMESTAMP
                        WHERE id=?""", (rel, st.st_size, mime, id))
                    fixed += 1
            else:
                ok += 1
            continue

        # 2) procurar na pasta da publicação
        folder = folder_for(anexos_dir, numero)
        if not folder or not os.path.isdir(folder):
            print(f"[MISS] id={id} numero={numero} (pasta inexistente)")
            missing += 1
            continue

        # 2a) por docseq extraído da URL
        m = PAT_DOCSEQ_URL.search(url_api)
        cand = find_candidate_by_docseq(folder, m.group(1)) if m else None

        # 2b) por título (fallback)
        if not cand:
            cand = find_candidate_by_titulo(folder, titulo)

        if cand and os.path.exists(cand):
            rel = norm_rel(proj_root, cand)
            st = os.stat(cand)
            mime = guess_mime(cand)
            print(f"[FIX] id={id} -> {rel}")
            if args.apply:
                conn.execute("""
                    UPDATE anexos SET saved_path=?, size_bytes=?, content_type=?, updated_at=CURRENT_TIMESTAMP
                    WHERE id=?""", (rel, st.st_size, mime, id))
                fixed += 1
        else:
            print(f"[MISS] id={id} numero={numero} (arquivo não encontrado na pasta)")
            missing += 1

    if args.apply:
        conn.commit()
    conn.close()

    print("\nResumo:")
    print(f"  OK (já válidos): {ok}")
    print(f"  Corrigidos:      {fixed}")
    print(f"  Ainda faltando:  {missing}")
    if not args.apply:
        print("\n(Dry-run) Nada foi gravado. Rode com --apply para aplicar.")

if __name__ == "__main__":
    main()
