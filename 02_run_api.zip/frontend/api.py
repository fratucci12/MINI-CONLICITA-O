import os
import io
import re
import json
import sqlite3
import zipfile
from typing import Any, Dict, List, Tuple, Optional
import requests
from fastapi import FastAPI, HTTPException, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse, JSONResponse

# -------------------------
# Config
# -------------------------
DB_PATH = os.getenv("DB_PATH", "pncp_db.sqlite")
ANEXOS_DIR = os.getenv("ANEXOS_DIR", "anexos")
PNCP_BASE = "https://pncp.gov.br/api/consulta/v1"
# Paginação PNCP (itens/buscas)
PNCP_PAGE_SIZE = int(os.getenv("PNCP_PAGE_SIZE", "200"))   # por página
PNCP_MAX_PAGES = int(os.getenv("PNCP_MAX_PAGES", "2000"))  # trava de segurança
PNCP_SLEEP_S   = float(os.getenv("PNCP_SLEEP_S", "0.03"))  # respiro entre páginas


_RX_NUMERO = re.compile(r"^\d{14}/\d{4}/\d+$")
def _is_numero_pncp(s: str) -> bool:
    return bool(_RX_NUMERO.match(str(s or "")))

app = FastAPI(title="Mini-ConLicitação API", version="1.0.0")

# CORS liberado em dev (ajuste em produção)
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5500",
        "http://127.0.0.1:5500",
        "http://localhost:8000",
        "http://127.0.0.1:8000",
        "*",  # (opcional em dev; remova em produção)
    ],
    allow_credentials=False,   # deixe False se não usa cookies/autenticação
    allow_methods=["*"],
    allow_headers=["*"],
)


# --- no topo do api.py (perto do DB_PATH) ---
DDL_PUBLICACOES = """
CREATE TABLE IF NOT EXISTS publicacoes (
  pub_id                 INTEGER PRIMARY KEY AUTOINCREMENT,
  numero_pncp            TEXT UNIQUE,
  orgao_nome             TEXT,
  orgao_cnpj             TEXT,
  uf                     TEXT,
  modalidade_nome        TEXT,
  modalidade_codigo      TEXT,
  sistema_publicador     TEXT,
  link_sistema_origem    TEXT,
  data_publicacao        TEXT,
  objeto                 TEXT,
  json_bruto             TEXT,
  created_at             TEXT DEFAULT CURRENT_TIMESTAMP,
  updated_at             TEXT DEFAULT CURRENT_TIMESTAMP
);
"""

DDL_ANEXOS = """
CREATE TABLE IF NOT EXISTS anexos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  numero_pncp TEXT NOT NULL,
  tipo_documento_id INTEGER NULL,
  tipo_documento_nome TEXT NULL,
  titulo TEXT NOT NULL DEFAULT '',
  url_api TEXT NOT NULL DEFAULT '',
  saved_path TEXT NULL,
  content_type TEXT NULL,
  size_bytes INTEGER NULL,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
  UNIQUE (numero_pncp, titulo, url_api)
);
"""

DDL_ITENS = """
CREATE TABLE IF NOT EXISTS itens (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  numero_pncp TEXT NOT NULL,
  pub_id INTEGER NULL,
  cnpj TEXT NOT NULL,
  ano INTEGER NOT NULL,
  sequencial INTEGER NOT NULL,
  lote TEXT NOT NULL DEFAULT '',
  numero_item INTEGER,
  descricao TEXT,
  unidade TEXT,
  quantidade REAL,
  valor_unitario REAL,
  valor_total REAL,
  json_bruto TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
  UNIQUE (numero_pncp, lote, numero_item)
);
"""

import os, io, re, json, zipfile, requests, urllib.parse

_MIME_TO_EXT = {
    "application/pdf": ".pdf",
    "application/zip": ".zip",
    "application/msword": ".doc",
    "application/vnd.ms-excel": ".xls",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document": ".docx",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": ".xlsx",
    "application/vnd.openxmlformats-officedocument.presentationml.presentation": ".pptx",
    "text/plain": ".txt",
    "text/csv": ".csv",
    "image/jpeg": ".jpg",
    "image/png": ".png",
    "image/gif": ".gif",
}

def _ext_from_content_type(ct: str|None):
    if not ct: return None
    return _MIME_TO_EXT.get(ct.split(";")[0].strip().lower())

def _ext_from_url(url: str):
    try:
        path = urllib.parse.urlparse(url).path
        ext = os.path.splitext(path)[1].lower()
        return ext if ext and len(ext) <= 6 else None
    except Exception:
        return None

def _decode_cd_filename(cd: str|None):
    if not cd: return None
    parts = [p.strip() for p in cd.split(";")]
    kv = {}
    for p in parts:
        if "=" in p:
            k,v = p.split("=",1)
            kv[k.lower()] = v.strip().strip('"')
    if "filename*" in kv:
        try:
            _, rest = kv["filename*"].split("''", 1)
            return urllib.parse.unquote(rest)
        except Exception:
            pass
    return kv.get("filename")

def _sniff_ext_from_head(head: bytes):
    if head.startswith(b"%PDF-"): return ".pdf"
    if head[:4] == b"PK\x03\x04":
        # ZIP/Office – tentar identificar pasta interna (precisa mais bytes para abrir)
        try:
            with zipfile.ZipFile(io.BytesIO(head)) as z:
                names = z.namelist()
                if any(n.startswith("word/") for n in names): return ".docx"
                if any(n.startswith("xl/") for n in names):   return ".xlsx"
                if any(n.startswith("ppt/") for n in names):  return ".pptx"
        except Exception:
            pass
        return ".zip"
    if head.startswith(b"\xFF\xD8\xFF"): return ".jpg"
    if head.startswith(b"\x89PNG\r\n\x1a\n"): return ".png"
    if head[:6] in (b"GIF87a", b"GIF89a"): return ".gif"
    return None

# ---------- Fallback: helpers de normalização/salvamento ----------

def _get(d: dict, *paths, default=None):
    for p in paths:
        cur = d
        ok = True
        for k in p.split("."):
            if isinstance(cur, dict) and k in cur:
                cur = cur[k]
            else:
                ok = False
                break
        if ok and cur not in (None, ""):
            return cur
    return default

def _norm_iso_sec(s: str|None) -> str|None:
    if not s: return None
    ss = s.strip().replace("Z","")
    try:
        # aceita 'YYYY-MM-DD', 'YYYY-MM-DDTHH:MM' ou já com segundos
        if len(ss) == 10:  return datetime.fromisoformat(ss + "T00:00:00").isoformat(timespec="seconds")
        if len(ss) == 16:  return datetime.fromisoformat(ss + ":00").isoformat(timespec="seconds")
        return datetime.fromisoformat(ss).isoformat(timespec="seconds")
    except Exception:
        return s  # se vier em outro formato, guarda assim mesmo


def _upsert_publicacao_from_payload(numero_pncp: str, payload: dict) -> dict:
    """Normaliza campos principais e faz UPSERT em publicacoes."""
    orgao_nome  = _get(payload, "orgaoEntidade.razaoSocial", "unidadeOrgao.nomeUnidade", "orgaoNome")
    uf          = _get(payload, "unidadeOrgao.ufSigla", "ufSigla", "uf")
    modalidade  = _get(payload, "modalidadeNome", "modalidade.nome", "modalidade")
    modalidade_cod = str(_get(payload, "modalidade", "modalidadeCodigo", default="") or "")
    link_origem = _get(payload, "linkSistemaOrigem", "linkProcessoEletronico")
    data_pub    = _get(payload, "dataPublicacaoPNCP", "dataPublicacaoPncp", "dataPublicacao", "dataInclusao")
    objeto      = _get(payload, "objetoCompra", "descricao", "objeto")
    data_ab     = _get(payload, "dataAberturaProposta", "dataInicioRecebimentoProposta",
                    "dataInicioPropostas", "dataAbertura")
    data_en     = _get(payload, "dataEncerramentoProposta", "dataFimRecebimentoProposta",
                    "dataEncerramento", "data_enceramento")
    row = {
        "numero_pncp": numero_pncp,
        "orgao_nome": orgao_nome,
        "uf": uf,
        "modalidade_nome": modalidade,
        "modalidade_codigo": modalidade_cod,
        "sistema_publicador": _get(payload, "sistemaPublicador", default=None),
        "link_sistema_origem": link_origem,
        "data_publicacao": _norm_iso_sec(data_pub),
        "data_abertura": _norm_iso_sec(data_ab),          # ✅ novo
        "data_encerramento": _norm_iso_sec(data_en),      # ✅ novo
        "objeto": objeto,
        "json_bruto": json.dumps(payload, ensure_ascii=False),
    }

    with connect_db() as con:
        con.execute("""
            INSERT INTO publicacoes
              (numero_pncp, orgao_nome, uf, modalidade_nome, modalidade_codigo,
               sistema_publicador, link_sistema_origem, data_publicacao,
               data_abertura, data_encerramento,                -- ✅ novo
               objeto, json_bruto, updated_at)
            VALUES
              (:numero_pncp, :orgao_nome, :uf, :modalidade_nome, :modalidade_codigo,
               :sistema_publicador, :link_sistema_origem, :data_publicacao,
               :data_abertura, :data_encerramento,              -- ✅ novo
               :objeto, :json_bruto, CURRENT_TIMESTAMP)
            ON CONFLICT(numero_pncp) DO UPDATE SET
               orgao_nome=excluded.orgao_nome,
               uf=excluded.uf,
               modalidade_nome=excluded.modalidade_nome,
               modalidade_codigo=excluded.modalidade_codigo,
               sistema_publicador=excluded.sistema_publicador,
               link_sistema_origem=excluded.link_sistema_origem,
               data_publicacao=excluded.data_publicacao,
               data_abertura=excluded.data_abertura,            -- ✅ novo
               data_encerramento=excluded.data_encerramento,    -- ✅ novo
               objeto=excluded.objeto,
               json_bruto=excluded.json_bruto,
               updated_at=CURRENT_TIMESTAMP
        """, row)
        saved = query_one("SELECT * FROM publicacoes WHERE numero_pncp=?", (numero_pncp,))
    return saved

def fetch_publicacao_meta_any(cnpj: str, ano: str, seq: str) -> Optional[dict]:
    """
    Tenta pegar o 'detalhe' na API do PNCP para qualquer família (compras/dispensas/inexigibilidades)
    e devolve o primeiro payload que vier 200/ok.
    """
    for res in RESOURCES:  # ["compras", "dispensas", "inexigibilidades"]
        url = f"{PNCP_FILES}/orgaos/{cnpj}/{res}/{ano}/{seq}"
        payload, sc, err = _http_get_json(url)
        if sc == 200 and isinstance(payload, dict) and payload:
            payload["_resource"] = res
            return payload
    return None

# preferência por tipo do documento (quando nada mais resolve)
def _prefer_ext_by_tipo(tipo_nome: str|None):
    if not tipo_nome: return None
    t = tipo_nome.lower()
    if "edital" in t: return ".pdf"
    if "termo de referência" in t or "termo de referencia" in t: return ".pdf"
    if "ata" in t: return ".pdf"
    return None

# --- Helpers de schema (coloque perto do _has_col)
import sqlite3
from functools import lru_cache

DB_PATH = DB_PATH  # aproveita a mesma constante já usada no seu projeto

@lru_cache(maxsize=64)
def _has_table(tbl: str) -> bool:
    """Retorna True se a tabela existir no SQLite."""
    try:
        with sqlite3.connect(DB_PATH) as con:
            cur = con.execute(
                "SELECT 1 FROM sqlite_master WHERE type='table' AND name=? LIMIT 1",
                (tbl,),
            )
            return cur.fetchone() is not None
    except Exception:
        return False



def connect_db() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON;")
    conn.execute(DDL_PUBLICACOES)
    conn.execute(DDL_ANEXOS)
    conn.execute(DDL_ITENS)

    # 🔧 migração leve: acrescenta colunas de data se faltarem
    try: conn.execute("ALTER TABLE publicacoes ADD COLUMN data_abertura TEXT")
    except sqlite3.OperationalError: pass
    try: conn.execute("ALTER TABLE publicacoes ADD COLUMN data_encerramento TEXT")
    except sqlite3.OperationalError: pass

    conn.commit()
    return conn



def query(sql: str, params: Tuple[Any, ...] = ()) -> List[Dict[str, Any]]:
    with connect_db() as conn:
        cur = conn.execute(sql, params)
        rows = [dict(r) for r in cur.fetchall()]
    return rows

def query_one(sql: str, params: Tuple[Any, ...] = ()) -> Optional[Dict[str, Any]]:
    rows = query(sql, params)
    return rows[0] if rows else None

# -------------------------
# PNCP Helpers (itens resiliente)
# -------------------------

PNCP_BASE  = "https://pncp.gov.br/api/consulta/v1"
PNCP_FILES = "https://pncp.gov.br/pncp-api/v1"
PNCP_ONLY = os.getenv("PNCP_ONLY", "0") == "1"     # DB ligado por padrão
PNCP_FALLBACK = os.getenv("PNCP_FALLBACK", "1") == "1"
PNCP_SKIP_ANEXOS = os.getenv("PNCP_SKIP_ANEXOS", "0") == "1"  # ← nova flag


RESOURCES = ["compras", "dispensas", "inexigibilidades"]

# -------- Itens (PNCP): listar com fallback entre famílias e variações de rota --------

# Se ainda não tiver, garanta:
# PNCP_FILES = "https://painel-compras-api.pncp.gov.br/api"  # ou o seu base
# RESOURCES = ("compras", "dispensas", "inexigibilidades")

def _to_list(payload):
    if payload is None:
        return []
    if isinstance(payload, list):
        return payload
    if isinstance(payload, dict):
        # algumas respostas vêm paginadas: {"content":[...]} | {"items":[...]} | {"data":[...]}
        for k in ("content", "items", "data", "lista", "resultado"):
            if k in payload and isinstance(payload[k], list):
                return payload[k]
    return []

def _norm_first(d: dict, *keys, default=None):
    for k in keys:
        v = d.get(k)
        if v not in (None, ""):
            return v
    return default

def list_itens_any(cnpj: str, ano: str, seq: str) -> list[dict]:
    """
    Tenta listar itens para (cnpj, ano, seq) em todas as famílias conhecidas do PNCP,
    testando variações comuns de rota/alias. Retorna a lista CRUA (como o PNCP entrega),
    mas cada item recebe a chave "_resource" com a família detectada.
    """
    # variações de caminho já vistas no PNCP
    suffixes = (
        "itens", "itens.json", "item", "itens-lote", "itensLote",
        "itens/0",  # alguns backends exigem índice/lote
    )

    for res in RESOURCES:
        # 1) rota "canônica" primeiro
        url = f"{PNCP_FILES}/orgaos/{cnpj}/{res}/{ano}/{seq}/itens"
        payload, sc, err = _http_get_json(url)
        if sc == 200:
            lst = _to_list(payload)
            for it in lst:
                if isinstance(it, dict):
                    it["_resource"] = res
            if lst:
                return lst

        # 2) tentar variações
        for suf in suffixes:
            url = f"{PNCP_FILES}/orgaos/{cnpj}/{res}/{ano}/{seq}/{suf}"
            payload, sc, err = _http_get_json(url)
            if sc == 200:
                lst = _to_list(payload)
                for it in lst:
                    if isinstance(it, dict):
                        it["_resource"] = res
                if lst:
                    return lst

    # 3) sem sucesso em nenhuma família
    return []

def normalize_item_row(raw: dict) -> dict:
    """
    Normaliza um item bruto do PNCP para o contrato que o seu frontend espera.
    Campos de saída:
      numero_item, descricao, unidade, quantidade, valor_unitario, valor_total, lote
    """
    return {
        "numero_item": _norm_first(raw,
            "numero_item", "numeroItem", "sequencialItem", "item", "numero"
        ),
        "descricao": _norm_first(raw,
            "descricao", "objeto", "descricaoItem", "descricaoResumida", "descricaoProduto"
        ),
        "unidade": _norm_first(raw,
            "unidade", "unidadeMedida", "unidade_fornecimento", "unidadeFornecimento"
        ),
        "quantidade": _norm_first(raw,
            "quantidade", "qtd", "quantidadeTotal", "qnt"
        ),
        "valor_unitario": _norm_first(raw,
            "valorUnitario", "valor_unitario", "precoUnitario", "valorEstimadoUnitario"
        ),
        "valor_total": _norm_first(raw,
            "valorTotal", "valor_total", "precoTotal", "valorEstimadoTotal"
        ),
        "lote": _norm_first(raw,
            "lote", "numeroLote", "sequencialLote"
        ),
    }

_PAT_NUM = re.compile(r"(\d{14})-\d-(\d{1,8})/(\d{4})")
def split_numero_pncp(num: str):
    m = _PAT_NUM.search(num or "")
    if not m:
        raise HTTPException(status_code=400, detail=f"numero_pncp inválido: {num}")
    cnpj, seq, ano = m.groups()
    return cnpj, ano, (seq.lstrip("0") or "0")

def _http_get_json(url: str, timeout=30):
    try:
        r = requests.get(url, timeout=timeout, headers={"Accept": "application/json"})
    except requests.RequestException as e:
        return None, 599, str(e)
    if r.status_code == 404:
        return None, 404, None
    if r.status_code != 200:
        return None, r.status_code, r.text
    try:
        return r.json(), 200, None
    except Exception:
        return None, 502, "non-JSON"

def _to_list(payload):
    if payload is None: return []
    if isinstance(payload, list): return payload
    if isinstance(payload, dict):
        for k in ("data","items","conteudo","resultado","itens"):
            v = payload.get(k)
            if isinstance(v, list): return v
    return []

def _with_pages(u: str):
    if "?" in u:
        base, qs = u.split("?", 1)
        return [u, f"{base}?pagina=1&tamanhoPagina=500&{qs}"]
    return [u, f"{u}?pagina=1&tamanhoPagina=500"]

def _try_itens(resource: str, cnpj: str, ano: str, seq: str):
    base = f"{PNCP_FILES}/orgaos/{cnpj}/{resource}/{ano}/{seq}"
    for u in _with_pages(f"{base}/itens"):
        payload, sc, err = _http_get_json(u)
        items = _to_list(payload)
        if sc == 200 and items:
            return items
    return []

def _try_lotes(resource: str, cnpj: str, ano: str, seq: str):
    base = f"{PNCP_FILES}/orgaos/{cnpj}/{resource}/{ano}/{seq}"
    lotes_payload, sc, err = _http_get_json(f"{base}/lotes")
    lotes = _to_list(lotes_payload)
    agregados = []
    if sc == 200 and lotes:
        for lote in lotes:
            num = (lote.get("numeroLote") or lote.get("numero") or lote.get("sequencialLote")
                   or lote.get("lote") or lote.get("id"))
            if num is None:
                continue
            for val in {str(num), str(num).lstrip("0")}:
                for u in _with_pages(f"{base}/lotes/{val}/itens"):
                    payload, sc_i, err_i = _http_get_json(u)
                    items = _to_list(payload)
                    if sc_i == 200 and items:
                        for it in items:
                            it["_lote"] = num
                        agregados.extend(items)
                        break
                if agregados and agregados[-1].get("_lote") == num:
                    break
    return agregados

def fetch_itens_any_resource(cnpj: str, ano: str, seq: str):
    for res in RESOURCES:
        items = _try_itens(res, cnpj, ano, seq)
        if items:
            return items
        items = _try_lotes(res, cnpj, ano, seq)
        if items:
            return items
    return []

def list_arquivos_any(cnpj: str, ano: str, seq: str):
    for res in RESOURCES:
        url = f"{PNCP_FILES}/orgaos/{cnpj}/{res}/{ano}/{seq}/arquivos"
        payload, sc, err = _http_get_json(url)
        lst = _to_list(payload)
        if sc == 200 and lst:
            for a in lst:
                a["_resource"] = res  # para montar URLs de download
            return lst
    return []

def stream_arquivo(cnpj: str, ano: str, seq: str, resource: str, docseq: str):
    url = f"{PNCP_FILES}/orgaos/{cnpj}/{resource}/{ano}/{seq}/arquivos/{docseq}"
    r = requests.get(url, stream=True, timeout=60)
    if r.status_code != 200:
        raise HTTPException(status_code=r.status_code, detail=f"PNCP: {r.text[:200]}")
    ct = r.headers.get("Content-Type", "application/octet-stream")
    cd = r.headers.get("Content-Disposition", "")
    headers = {"Content-Disposition": cd} if cd else {}
    return StreamingResponse(r.iter_content(chunk_size=8192), media_type=ct, headers=headers)


# -------------------------
# UTIL: anexos locais
# -------------------------
def _resolve_saved_path(saved_path: str) -> Optional[str]:
    if not saved_path:
        return None
    # Se vier com barra invertida do Windows no banco, normalize
    p = saved_path.replace("\\", os.sep).replace("/", os.sep)
    # Caminho relativo dentro de "anexos/"
    rel = os.path.join(ANEXOS_DIR, p) if not os.path.isabs(p) else p
    if os.path.exists(rel):
        return rel
    # Tenta direto (alguns salvam "anexos\..."):
    if os.path.exists(p):
        return p
    return None

def _list_anexos_by_numero(numero_pncp: str) -> List[Dict[str, Any]]:
    return query(
        """
        SELECT id, numero_pncp, tipo_documento_nome, titulo, url_api, saved_path, content_type, size_bytes
        FROM anexos
        WHERE numero_pncp=? 
        ORDER BY id
        """,
        (numero_pncp,),
    )

def _list_anexos_by_pubid(pub_id: int) -> List[Dict[str, Any]]:
    return query(
        """
        SELECT a.id, a.numero_pncp, a.tipo_documento_nome, a.titulo, a.url_api, a.saved_path, a.content_type, a.size_bytes
        FROM anexos a
        JOIN publicacoes p ON p.numero_pncp = a.numero_pncp
        WHERE p.pub_id=?
        ORDER BY a.id
        """,
        (pub_id,),
    )

# -------------------------
# Endpoints
# -------------------------

@app.get("/health")
def health():
    return {
        "ok": True,
        "message": "Mini-ConLicitação API",
        "endpoints": [
            "/health", "/buscar",
            "/detalhe/{numero_pncp}", "/detalhe_id/{pub_id}",
            "/anexos/{numero_pncp}", "/anexos_id/{pub_id}", "/anexos_id/{pub_id}/zip",
            "/itens/{numero_pncp}", "/itens_id/{pub_id}",
            "/debug/itens_id/{pub_id}", "/debug/itens_fetch_all/{pub_id}",
        ],
    }

# helpers (cole perto dos outros utils)
def _has_col(table: str, col: str) -> bool:
    with connect_db() as conn:
        cur = conn.execute(f"PRAGMA table_info({table})")
        return any(r["name"] == col for r in cur.fetchall())

def _order_expr_publicacoes() -> str:
    # monta COALESCE com as colunas que existem no seu schema
    cols = ["updated_at"]
    if _has_col("publicacoes", "dataAtualizacaoGlobal"):
        cols.append("dataAtualizacaoGlobal")   # só se existir
    cols += ["data_publicacao", "created_at"]
    return "datetime(COALESCE(" + ",".join(cols) + "))"

from datetime import datetime

def _coalesce_cols(tbl: str, cols: tuple[str, ...]) -> str:
    exist = [c for c in cols if _has_col(tbl, c)]
    return f"COALESCE({', '.join(exist)})" if exist else "NULL"

def _dateexpr(tbl: str, candidates: tuple[str, ...]) -> str:
    """
    Monta uma expressão 'COALESCE(col1, col2, ...)' apenas com colunas que existem.
    Use datas armazenadas em ISO-8601 (YYYY-MM-DDTHH:MM:SS) para comparação lexical segura.
    """
    exist = [c for c in candidates if _has_col(tbl, c)]
    return f"COALESCE({', '.join(exist)})" if exist else "NULL"

def _norm_dt(s: str | None, end=False) -> str | None:
    if not s: return None
    # aceita 'YYYY-MM-DD', 'YYYY-MM-DDTHH:MM', 'YYYY-MM-DDTHH:MM:SS'
    s = s.strip()
    try:
        if len(s) == 10:
            dt = datetime.fromisoformat(s + ("T23:59:59" if end else "T00:00:00"))
        elif len(s) == 16:
            dt = datetime.fromisoformat(s + ":00")
        else:
            dt = datetime.fromisoformat(s)
        return dt.isoformat(timespec="seconds")
    except Exception:
        return None

def _pncp_search_headers(q: str, limit: int = 20) -> list[dict]:
    # Busca simples nas 3 famílias; ajusta conforme sua necessidade
    out = []
    for res in RESOURCES:
        # Exemplo de consulta: pncp-api (headers variam entre instâncias)
        url = f"{PNCP_FILES}/{res}/busca?pagina=1&tamanhoPagina={limit}&termo={requests.utils.quote(q)}"
        payload, sc, err = _http_get_json(url)
        if sc == 200:
            lst = _to_list(payload)
            for h in lst:
                h["_resource"] = res
            out.extend(lst)
        if len(out) >= limit:
            break
    return out[:limit]

@app.get("/buscar")
def buscar(q: str = "", in_itens: bool = True, uf: str = "", orgao: str = "", edital: str = "",
           modal: str = "", abertura_de: str = "", abertura_ate: str = "",
           encerramento_de: str = "", encerramento_ate: str = "", limit: int = 50):
    if PNCP_ONLY:
        if not q:
            # opcional: pode retornar [] ou exigir q
            return []
        # 1) busca cabeçalhos no PNCP
        headers = _pncp_search_headers(q, limit=min(limit, 50))  # você já tem esta função no arquivo
        out = []
        for h in headers:
            numero = _get(h, "numeroControlePNCP", "numero_pncp")
            if not numero: 
                continue
            try:
                cnpj, ano, seq = split_numero_pncp(numero)
            except HTTPException:
                continue
            # 2) tenta detalhe completo (melhor para normalizar)
            payload = fetch_publicacao_meta_any(cnpj, ano, seq) or h  # você já tem estas funções
            row = {
                "pub_id": numero,  # usamos o próprio número PNCP como “id”
                "numero_pncp": numero,
                "orgao_nome": _get(payload, "orgaoEntidade.razaoSocial", "unidadeOrgao.nomeUnidade", "orgaoNome"),
                "municipioNome": _get(payload, "unidadeOrgao.municipioNome", "municipioNome", "municipio"),
                "uf": _get(payload, "unidadeOrgao.ufSigla", "uf"),
                "modalidade_nome": _get(payload, "modalidadeNome", "modalidade.nome", "modalidade"),
                "modalidade_codigo": str(_get(payload, "modalidade", "modalidadeCodigo", default="") or ""),
                "edital": _get(payload, "numeroEdital", "numeroCompra", "edital"),
                "data_publicacao": _get(payload, "dataPublicacaoPNCP", "dataPublicacaoPncp", "dataPublicacao", "dataInclusao"),
                "dataAberturaProposta": _get(payload, "dataAberturaProposta", "dataInicioRecebimentoProposta", "dataInicioPropostas", "dataAbertura"),
                "dataEncerramentoProposta": _get(payload, "dataEncerramentoProposta", "dataFimRecebimentoProposta", "dataEncerramento", "data_enceramento"),
                "objeto": _get(payload, "objetoCompra", "descricao", "objeto"),
                "link_sistema_origem": _get(payload, "linkSistemaOrigem", "linkProcessoEletronico"),
                "json_bruto": json.dumps(payload, ensure_ascii=False),
            }
            out.append(row)

        # 3) aplica filtros em memória (case-insensitive)
        def _norm(s): return (s or "").strip().lower()
        def _in(s, sub): return _norm(sub) in _norm(s)
        def _to_iso(s): 
            try:
                return _norm_dt(s)  # você já tem _norm_dt no arquivo
            except Exception:
                return None

        flt = []
        for r in out:
            ok = True
            if uf and _norm(r.get("uf")) != _norm(uf): ok = False
            if orgao and not _in(r.get("orgao_nome"), orgao): ok = False
            if edital and not _in(r.get("edital"), edital): ok = False
            if modal:
                if modal.isdigit():
                    ok = ok and _norm(r.get("modalidade_codigo")) == _norm(modal)
                else:
                    ok = ok and _in(r.get("modalidade_nome"), modal)
            if (abertura_de or abertura_ate):
                ab = r.get("dataAberturaProposta")
                abi = _to_iso(ab)
                if abertura_de and abi and abi < _norm_dt(abertura_de): ok = False
                if abertura_ate and abi and abi > _norm_dt(abertura_ate, end=True): ok = False
            if (encerramento_de or encerramento_ate):
                en = r.get("dataEncerramentoProposta")
                eni = _to_iso(en)
                if encerramento_de and eni and eni < _norm_dt(encerramento_de): ok = False
                if encerramento_ate and eni and eni > _norm_dt(encerramento_ate, end=True): ok = False
            if ok: flt.append(r)

        return flt[:limit]


@app.get("/detalhe/{numero_pncp}")
def detalhe_numero(numero_pncp: str):
    row = query_one("SELECT * FROM publicacoes WHERE numero_pncp=?", (numero_pncp,))
    if row:
        return row

    if not PNCP_FALLBACK:
        raise HTTPException(404, "numero_pncp não encontrado")

    # Fallback PNCP
    try:
        cnpj, ano, seq = split_numero_pncp(numero_pncp)
    except HTTPException:
        # formato inválido -> sem como buscar no PNCP
        raise HTTPException(404, "numero_pncp não encontrado")

    payload = fetch_publicacao_meta_any(cnpj, ano, seq)
    if not payload:
        raise HTTPException(404, "numero_pncp não encontrado no PNCP")

    saved = _upsert_publicacao_from_payload(numero_pncp, payload)
    return saved

@app.get("/detalhe_id/{pub_id}")
def detalhe_id(pub_id: int):
    if PNCP_ONLY:
        # trate pub_id como numero_pncp (o front vai passar isso)
        if not _is_numero_pncp(pub_id):
            raise HTTPException(404, "Neste modo, use numero_pncp como ID")
        cnpj, ano, seq = split_numero_pncp(pub_id)
        payload = fetch_publicacao_meta_any(cnpj, ano, seq)
        if not payload:
            raise HTTPException(404, "não encontrado no PNCP")
        # devolve no mesmo layout que o front espera
        return {
            "pub_id": pub_id,
            "numero_pncp": pub_id,
            "json_bruto": json.dumps(payload, ensure_ascii=False),
            "objeto": _get(payload, "objetoCompra", "descricao", "objeto"),
            "orgao_nome": _get(payload, "orgaoEntidade.razaoSocial", "unidadeOrgao.nomeUnidade", "orgaoNome"),
            "municipioNome": _get(payload, "unidadeOrgao.municipioNome", "municipioNome", "municipio"),
            "uf": _get(payload, "unidadeOrgao.ufSigla", "uf"),
            "modalidade_nome": _get(payload, "modalidadeNome", "modalidade.nome", "modalidade"),
            "edital": _get(payload, "numeroEdital", "numeroCompra", "edital"),
            "data_publicacao": _get(payload, "dataPublicacaoPNCP", "dataPublicacaoPncp", "dataPublicacao", "dataInclusao"),
            "dataAberturaProposta": _get(payload, "dataAberturaProposta", "dataInicioRecebimentoProposta","dataInicioPropostas","dataAbertura"),
            "dataEncerramentoProposta": _get(payload, "dataEncerramentoProposta","dataFimRecebimentoProposta","dataEncerramento","data_enceramento"),
            "link_sistema_origem": _get(payload, "linkSistemaOrigem", "linkProcessoEletronico"),
        }
    row = query_one("SELECT * FROM publicacoes WHERE pub_id=?", (pub_id,))
    if not row:
        raise HTTPException(404, "pub_id não encontrado")
    return row

@app.get("/anexos/{numero_pncp}")
def anexos_numero(numero_pncp: str):
    rows = _list_anexos_by_numero(numero_pncp)
    for r in rows:
        r["resolved_path"] = _resolve_saved_path(r.get("saved_path") or "")

    have_local = [r for r in rows if r.get("resolved_path")]
    if have_local or not PNCP_FALLBACK:
        return rows

    # Fallback PNCP: lista remota
    try:
        cnpj, ano, seq = split_numero_pncp(numero_pncp)
    except HTTPException:
        return rows  # formato inválido; não há fallback possível

    remotos = list_arquivos_any(cnpj, ano, seq)
    out = []
    for a in remotos:
        docseq = a.get("sequencial_documento") or a.get("sequencialDocumento") or a.get("id")
        out.append({
            "id": docseq,
            "numero_pncp": numero_pncp,
            "tipo_documento_nome": a.get("tipo_documento_nome") or a.get("tipoDocumentoNome"),
            "titulo": a.get("titulo") or a.get("descricao"),
            "saved_path": None,
            "resolved_path": None,
            "remote": True,
            "resource": a.get("_resource"),
            # proxy por numero -> usa mesmo handler do _id via detalhe/numero
            "proxy_url": f"/anexos_numero/{numero_pncp}/remote/{a.get('_resource')}/{docseq}"
        })
    return out

@app.get("/anexos_id/{pub_id}")
def anexos_id(pub_id: int):
    rows = _list_anexos_by_pubid(pub_id)
    for r in rows:
        r["resolved_path"] = _resolve_saved_path(r.get("saved_path") or "")
    # Se já tem locais no DB, retorna
    have_local = [r for r in rows if r.get("resolved_path")]
    if have_local or not PNCP_FALLBACK:
        return rows

    # Se não tem locais e quer pular anexos, ainda assim mostre os remotos (sem baixar)
    row = query_one("SELECT numero_pncp FROM publicacoes WHERE pub_id=?", (pub_id,))
    if not row:
        raise HTTPException(status_code=404, detail="pub_id não encontrado")
    try:
        cnpj, ano, seq = split_numero_pncp(row["numero_pncp"])
    except HTTPException:
        return rows

    remotos = list_arquivos_any(cnpj, ano, seq)  # apenas lista; não baixa
    out = []
    for a in remotos:
        docseq = a.get("sequencial_documento") or a.get("sequencialDocumento") or a.get("id")
        out.append({
            "id": docseq,
            "numero_pncp": row["numero_pncp"],
            "tipo_documento_nome": a.get("tipo_documento_nome") or a.get("tipoDocumentoNome"),
            "titulo": a.get("titulo") or a.get("descricao"),
            "saved_path": None,
            "resolved_path": None,
            "remote": True,
            "resource": a.get("_resource"),
            # proxy direto do PNCP → sem armazenar no disco
            "proxy_url": f"/anexos_id/{pub_id}/remote/{a.get('_resource')}/{docseq}"
        })
    return out

@app.get("/anexos_id/{pub_id}/remote/{resource}/{docseq}")
def anexos_id_remote(pub_id: int, resource: str, docseq: str):
    row = query_one("SELECT numero_pncp FROM publicacoes WHERE pub_id=?", (pub_id,))
    if not row:
        raise HTTPException(status_code=404, detail="pub_id não encontrado")
    cnpj, ano, seq = split_numero_pncp(row["numero_pncp"])
    return stream_arquivo(cnpj, ano, seq, resource, docseq)


@app.get("/anexos_id/{pub_id}/zip")
def anexos_zip(pub_id: int):
    anexos = _list_anexos_by_pubid(pub_id)
    locais = []
    for a in anexos:
        p = _resolve_saved_path(a.get("saved_path") or "")
        if p: locais.append((p, a))

    if locais:
        # zip apenas de arquivos locais
        def gen_local():
            with io.BytesIO() as mem:
                with zipfile.ZipFile(mem, "w", zipfile.ZIP_DEFLATED) as z:
                    for fullpath, meta in locais:
                        base = os.path.basename(fullpath)
                        tipo = (meta.get("tipo_documento_nome") or "DOC").strip()
                        titulo = (meta.get("titulo") or "").strip()
                        ext = os.path.splitext(base)[1] or ".bin"
                        seq = str(meta.get("id") or "0").zfill(3)
                        name_in_zip = f"{seq} - {tipo}" + (f" - {titulo}" if titulo else "") + ext
                        try:
                            z.write(fullpath, arcname=name_in_zip)
                        except Exception:
                            z.write(fullpath, arcname=base)
                mem.seek(0)
                yield from mem
        headers = {"Content-Disposition": f'attachment; filename="anexos_pub_{pub_id}.zip"'}
        return StreamingResponse(gen_local(), media_type="application/zip", headers=headers)

    # 👉 Sem locais: não monta zip remoto. Retorna 204 (No Content).
    return Response(status_code=204)

# -------- ITENS --------

@app.get("/itens_id/{pub_id}")
def itens_por_pub_id(pub_id: int):
    # 1) tenta local
    if PNCP_ONLY:
        if not _is_numero_pncp(pub_id):
            raise HTTPException(404, "Use numero_pncp como ID no modo PNCP_ONLY")
        cnpj, ano, seq = split_numero_pncp(pub_id)
        # você já tem listagem/normalização de itens via PNCP — chame a função que usa RESOURCES
        itens = list_itens_any(cnpj, ano, seq)  # mesma ideia do seus anexos
        # normaliza para o layout que o front espera
        out = []
        for it in itens:
            out.append({
                "numero_item": it.get("numero_item") or it.get("numeroItem") or it.get("sequencialItem"),
                "descricao": it.get("descricao") or it.get("objeto"),
                "unidade": it.get("unidade") or it.get("unidadeMedida"),
                "quantidade": it.get("quantidade"),
                "valor_unitario": it.get("valorUnitario"),
                "valor_total": it.get("valorTotal"),
                "lote": it.get("lote"),
            })
        return out
    local_rows = query("""
        SELECT numero_item AS numero_item, descricao, unidade, quantidade,
               valor_unitario AS valor_unitario, valor_total AS valor_total, lote
        FROM itens WHERE pub_id=?
        ORDER BY COALESCE(lote,''), numero_item
    """, (pub_id,))
    if local_rows:
        return local_rows

    # 2) fallback PNCP
    if not PNCP_FALLBACK:
        return []

    row = query_one("SELECT numero_pncp FROM publicacoes WHERE pub_id=?", (pub_id,))
    if not row:
        raise HTTPException(status_code=404, detail="pub_id não encontrado")
    cnpj, ano, seq = split_numero_pncp(row["numero_pncp"])
    itens = fetch_itens_any_resource(cnpj, ano, seq)
    return itens  # já no formato do PNCP; o front atual aceita

@app.get("/itens/{numero_pncp:path}")
def itens_por_numero(numero_pncp: str):
    cnpj, ano, seq = split_numero_pncp(numero_pncp)
    return fetch_itens_any_resource(cnpj, ano, seq)


# -------- DEBUG --------

@app.get("/debug/itens_id/{pub_id}")
def debug_itens_url(pub_id: int):
    row = query_one("SELECT numero_pncp FROM publicacoes WHERE pub_id=?", (pub_id,))
    if not row:
        raise HTTPException(404, "pub_id não encontrado")
    numero = row["numero_pncp"]
    cnpj, ano, seq = split_numero_pncp(numero)
    return {
        "pub_id": pub_id,
        "numero_pncp": numero,
        "urls": {
            "compras_itens": f"{PNCP_BASE}/orgaos/{cnpj}/compras/{ano}/{seq}/itens",
            "compras_lotes": f"{PNCP_BASE}/orgaos/{cnpj}/compras/{ano}/{seq}/lotes",
            "dispensas_itens": f"{PNCP_BASE}/orgaos/{cnpj}/dispensas/{ano}/{seq}/itens",
            "inexig_itens": f"{PNCP_BASE}/orgaos/{cnpj}/inexigibilidades/{ano}/{seq}/itens",
        },
    }

@app.get("/debug/itens_fetch_all/{pub_id}")
def debug_itens_fetch_all(pub_id: int):
    row = query_one("SELECT numero_pncp FROM publicacoes WHERE pub_id=?", (pub_id,))
    if not row:
        raise HTTPException(404, "pub_id não encontrado")
    numero = row["numero_pncp"]
    cnpj, ano, seq = split_numero_pncp(numero)

    report = {"pub_id": pub_id, "numero_pncp": numero, "resources": []}
    # tenta direto e por lotes em cada família
    for res in RESOURCES:
        it_dir, dbg_i = _try_itens(res, cnpj, ano, seq)
        it_lot, dbg_l = _try_lotes(res, cnpj, ano, seq)
        report["resources"].append({
            "resource": res,
            "direto": {"total": len(it_dir), **dbg_i},
            "lotes":  {"total": len(it_lot), **dbg_l},
        })
    return report
